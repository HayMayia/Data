# VocalBridge — FULL DATA **WITH SPEAKER**
### Idea + BOM + wiring + calibration + phases (Grade 8 / vivo Ignite 2026)

---

# 0) Quick decision: which “speaker” should you use?

Adding audio is better for judges **if** it doesn’t break your timeline.

| Option | What it is | Extra work | Extra cost | Demo wow | Recommendation |
|---|---|---|---:|---|---|
| **S0 — Phone/laptop TTS** | Screen shows HELP + phone speaks | Almost none | ₹0 | High | **Best default** |
| **S1 — Active USB/3.5mm speaker** | Plug into laptop that runs Python | Very low | ₹200–600 | High | Easy if demo on laptop |
| **S2 — Passive buzzer / beep** | Beep pattern for HELP | Low | ₹10–30 | Low–Med | Backup only |
| **S3 — DFPlayer Mini + speaker** | ESP32 triggers pre-recorded “Help.mp3” | Medium | ₹250–450 | **High (standalone)** | **Best onboard speaker** |
| **S4 — I2S amp + speaker** | True TTS on ESP32 | High | ₹400–800 | High | **Too much for now** |

**Recommended path**
1. **Submit idea** mentioning speaker / voice output  
2. **Phase‑1 demo:** phone/laptop TTS **or** DFPlayer saying “Help”  
3. Skip S4 until Phase‑1 works  

---

# 1) Project summary (with speaker)

**Title:**  
VocalBridge: Low-Cost Subvocal EMG Communication for Non-Verbal Individuals

**One-liner:**  
A low-cost wearable that reads residual speech-muscle signals (EMG) and turns a few emergency words into **spoken audio + on-screen text**.

**How it “knows” HELP (reminder):**  
Sensors auto-record muscle waves → you **label** training examples → code matches new waves to the HELP cloud → if confident, **speaker says “Help”**.

**SDGs to select on portal:**  
- **3** Good Health and Well-Being (**primary**)  
- **10** Reduced Inequalities (**secondary**)  
- Optional: **9** Industry, Innovation and Infrastructure  

---

# 2) System pipeline **with speaker**

```
Throat/jaw/arm electrodes
        ↓
AD8232 amplifier(s)
        ↓
ESP32 samples signal
        ↓
USB or BLE → laptop/phone  (Phase‑1 can stay USB)
        ↓
Filter + threshold or small ML
        ↓
If label = HELP and confidence high
        ↓
   ┌───────────────┬────────────────────┐
   ↓               ↓                    ↓
On-screen text   SPEAKER audio      (optional log)
  "HELP"         "Help" voice/beep
```

**Speaker branch choices**
- **A)** Laptop/phone TTS (easiest)  
- **B)** DFPlayer on ESP32 plays `0001_help.mp3` (best self-contained demo)  
- **C)** Both (screen + speaker)

---

# 3) FULL BILL OF MATERIALS (WITH SPEAKER)

Prices India retail approx. (±20–30%).

## 3.1 Phase‑1 MINI kit + easiest voice (recommended start)

| # | Item | Qty | Approx. ₹ | Function | Notes |
|---|---|---:|---:|---|---|
| 1 | ESP32 DevKit | 1 | 300–400 | Brain / ADC / control | Arduino IDE |
| 2 | AD8232 ECG/EMG module | 1 | 250–350 | Amplifies muscle signal | Start with 1 channel |
| 3 | Disposable ECG electrodes | 1 pack | 150–300 | Skin contact sensors | Replace when dry |
| 4 | Electrode cable/snaps | 1 | 0–100 | Connect pads to AD8232 | Often included |
| 5 | Breadboard | 1 | 70–100 | Prototyping | |
| 6 | Jumper wires M‑M | 1 set | 40–80 | Wiring | |
| 7 | USB data cable | 1 | 50–100 | Code + Serial Plotter | Not charge-only |
| 8 | Power bank 5V | 1 | 0–400 | Safer skin-powered demo | Prefer vs wall-only |
| 9 | Strap / tape + notebook | — | 50–100 | Mount + lab log | |
| **10a** | **Phone or laptop speaker (TTS)** | 1 | **0** | **Speaks “Help”** | **Easiest voice** |
| **10b** | *OR cheap PC speaker 3.5mm/USB* | 1 | 200–600 | Louder laptop demo | Optional |

**Phase‑1 mini total (with phone TTS): ~₹1,100 – ₹1,500**  
**Phase‑1 mini + USB speaker: ~₹1,400 – ₹2,100**

---

## 3.2 Onboard speaker kit (DFPlayer) — add when Phase‑1 signal works

| # | Item | Qty | Approx. ₹ | Function | Calibration / setup |
|---|---|---:|---:|---|---|
| 11 | **DFPlayer Mini** MP3 module | 1 | 120–200 | Plays voice files from microSD when ESP32 says “play track 1” | Load SD with `0001.mp3` = Help, `0002.mp3` = Yes… |
| 12 | **microSD card** (≤32GB, FAT32) | 1 | 100–200 | Stores voice clips | Format FAT32; short clear recordings |
| 13 | **0.5W–3W speaker** (4Ω/8Ω) | 1 | 40–120 | Physical sound output | Don’t drive speaker without DFPlayer amp |
| 14 | Extra jumpers | few | 20 | DFPlayer ↔ ESP32 | TX/RX cross if needed |
| 15 | Optional 1kΩ resistor | 1 | 5 | Sometimes on serial line | Stability |

**DFPlayer add-on total: ~₹250 – ₹450**

**Phase‑1 + DFPlayer grand total: ~₹1,400 – ₹2,000**

---

## 3.3 Option A full path (closer to abstract, still realistic)

| Item | Qty | Approx. ₹ | Function |
|---|---:|---:|---|
| ESP32 | 1 | 350 | MCU + optional BLE |
| AD8232 | 3 | 750–1050 | Multi-channel EMG |
| Electrodes pack | 1–2 | 250–500 | Sensing |
| Breadboard + wires + USB | 1 | 200 | Wiring |
| Power bank / LiPo+TP4056 | 1 | 250–400 | Power |
| Strap / neckband materials | 1 | 100–250 | Wearable demo |
| **DFPlayer + microSD + speaker** | 1 set | **300–450** | **On-device speech** |
| Optional ADS1115 | 1 | 280 | Better ADC |
| Optional OLED | 1 | 150–250 | Show word on band |

**Option A with speaker: ~₹2,400 – ₹3,500**

---

## 3.4 What NOT to buy yet

| Skip for now | Why |
|---|---|
| Big Bluetooth speaker DIY stack | Extra debug |
| I2S high-end audio boards | Too complex |
| Multiple high-power amps | Heat, wiring, noise into EMG |
| Professional EMG kit (₹15k+) | Budget / not required for idea |

---

# 4) Speaker options — function & how to “calibrate”

## 4.1 Phone / laptop TTS (S0) — do this first

**Function:** When code prints/classifies HELP, OS voice says “Help”.

**How**
- Arduino Serial → Python script reads line `"HELP"` → `pyttsx3` / Windows SAPI / phone app  
- Or demo: Python ML pipeline speaks directly  

**Calibration**
- Volume test in quiet room  
- Latency check: speak within ~0.5–1 s of trigger  
- Don’t let TTS spam: only speak on **new** detection edge (not every sample)

**Pros:** zero extra EMG noise, fastest  
**Cons:** tethered to phone/laptop (OK for competition video)

---

## 4.2 DFPlayer Mini + speaker (S3) — best “I built a speaker into it”

**Function:** ESP32 sends “play file 0001” → speaker says recorded “Help”.

**Voice files to put on SD (example)**
```
/mp3/0001.mp3  → Help
/mp3/0002.mp3  → Yes
/mp3/0003.mp3  → No
/mp3/0004.mp3  → Water
/mp3/0005.mp3  → Pain
/mp3/0006.mp3  → (optional error beep)
```
Record with phone voice recorder, clear and slow; convert to mp3 if needed.

**DFPlayer pin map (typical)**
| DFPlayer | ESP32 | Notes |
|---|---|---|
| VCC | 5V (or 3.3V if module allows — many want 5V) | Check module; often 5V |
| GND | GND | Common ground |
| RX | GPIO26 (via 1k if needed) | ESP32 TX → DF RX |
| TX | GPIO27 | ESP32 RX ← DF TX |
| SPK_1 / SPK_2 | Speaker wires | Use DFPlayer speaker pins, not random GPIO |

**Library:** `DFRobotDFPlayerMini` or soft serial commands in Arduino.

**Calibration / setup checklist**
1. Format SD **FAT32**  
2. Copy files with correct numeric names  
3. Test DFPlayer alone: play track 1 on boot  
4. Only then connect to HELP trigger  
5. Volume command mid-level (too loud can rattle wires)  
6. **Debounce:** play once per detection, then cooldown 1–2 s  

**Critical interaction with EMG**
Speaker current can inject noise into AD8232.
**Mitigations:**
- Separate power paths if possible  
- Short speaker wires  
- Don’t place speaker cable over electrode wires  
- Trigger speech **after** window classification, not during sampling if noise appears  
- If plot goes crazy when speaker plays: add cooldown / physical separation / use phone TTS instead for video  

---

## 4.3 Passive buzzer (S2) — emergency backup

**Function:** HELP = 3 short beeps (not a real word).

| Item | ₹ | Wiring |
|---|---:|---|
| Active buzzer | 10–30 | GPIO → buzzer → GND (check active vs passive) |

**Calibration:** beep pattern distinct; not continuous scream.

Use only if voice fails before video day.

---

# 5) Wiring overview (Phase‑1 + DFPlayer)

```
[Electrodes]──[AD8232]──OUTPUT──> ESP32 GPIO34
                  │
                 3V3/GND shared with ESP32 (careful, clean)

ESP32 GPIO26 ──> DFPlayer RX
ESP32 GPIO27 <── DFPlayer TX
ESP32 5V/VIN ──> DFPlayer VCC (as per module)
ESP32 GND   ──> DFPlayer GND
DFPlayer SPK ──> Speaker

ESP32 USB ──> PC (programming / plotter)
Power bank recommended for skin-connected demos
```

**Safety**
- Surface electrodes only  
- Parent present first tests  
- Prefer power bank when pads on skin  
- Not a medical device  
- Stop if skin irritation  

---

# 6) Software stack (with speaker)

| Stage | Software | Speaker action |
|---|---|---|
| Day 1–3 | Arduino + Serial Plotter | none yet |
| Day 4–7 | Arduino threshold → `Serial.println("HELP")` | Python TTS on PC **or** DFPlayer play(1) |
| Later | Python filter + RF/CNN | TTS or ESP32→DFPlayer |
| Optional | BLE app | phone speaks |

### Minimal Arduino logic (concept)
```text
read EMG
if strength > T for 200ms and cooldown finished:
    print "HELP"
    dfplayer.play(1)    // or skip if using PC TTS
    start cooldown 1500ms
```

### Minimal Python TTS logic (concept)
```text
if serial line == "HELP":
    speak("Help")
```

---

# 7) Calibration **with** speaker (full loop)

## 7.1 Physical signal calibration (no speaker first)
1. Rest flat-ish on Serial Plotter  
2. Action (clench / mouth HELP) clearly higher  
3. Notebook: rest avg, action avg  
4. Choose threshold T  

**Pass gate:** visible difference 8/10 times **before** adding speaker.

## 7.2 Detection calibration
1. Tune T so few false HELPs at rest  
2. Add debounce 200–300 ms  
3. Add cooldown 1–2 s so speaker doesn’t stutter  

## 7.3 Speaker calibration
1. Play “Help” alone (button or boot test) — clear audio?  
2. Trigger from fake Serial command  
3. Trigger from real muscle  
4. If EMG noise when speaking → separate wires / use phone TTS for final video  

## 7.4 Word training (later)
- ~50–100 HELP + ~50–100 REST  
- Optional few soft + strong HELPs for small tolerance  
- Small difference OK inside HELP cloud  
- Weak almost-rest HELP may stay silent (good)

## 7.5 Multi-word + multi-file speaker (later)
| Word | SD file | When |
|---|---|---|
| Help | 0001.mp3 | class 1 |
| Yes | 0002.mp3 | class 2 |
| No | 0003.mp3 | class 3 |
| Water | 0004.mp3 | class 4 |
| Pain | 0005.mp3 | class 5 |

Only after 2-class works.

---

# 8) Phased build plan **including speaker**

| Phase | Goal | Speaker | Time guide |
|---|---|---|---|
| **P0** | Blink + Serial Plotter + EMG wave | Off | 2–4 days after parts |
| **P1** | REST vs HELP threshold | **Phone TTS or DFPlayer “Help”** | +3–7 days |
| **P2** | Cleaner filter + cooldown + reliable demo video | Keep one speaker method | +3–7 days |
| **P3** | 2nd word YES + 0002.mp3 | Multi-track | weeks |
| **P4** | 3 channels + 5 words + neck strap | Full story | months / post-shortlist |

**Video success definition**
> Mouth/clench HELP → speaker clearly says “Help” (and screen shows HELP) about 8/10 times.

Not: 5 words perfect in 2 weeks.

---

# 9) Abstract blurb — include speaker (optional edit)

You can keep your current abstract; if you want speaker explicit, add half a sentence:

> “…and outputs the word on screen **and through a speaker / text-to-speech** so caregivers can hear the request.”

Still stay within 150–300 words total.

---

# 10) Poster points — speaker

Add under methodology / results:
- Output: **visual + audible** (“Help”)  
- Audio path: TTS and/or DFPlayer + small speaker  
- Safety: cooldown + confidence to avoid spam/wrong speech  
- Cost still under ~₹2,500–3,500 with speaker  

---

# 11) Cost summary (with speaker)

| Package | Approx. ₹ | What judges hear |
|---|---:|---|
| Mini EMG + **phone TTS** | 1,100–1,500 | “Help” from phone |
| Mini EMG + **USB speaker on PC** | 1,400–2,100 | Louder “Help” |
| Mini EMG + **DFPlayer + speaker** | 1,400–2,000 | Onboard “Help” |
| Fuller 3-ch + DFPlayer | 2,400–3,500 | Closer to product story |

---

# 12) Workload truth (you said speaker increases work)

| Task | Extra time |
|---|---|
| Phone TTS | **+0.5–1 day** after HELP prints on Serial |
| DFPlayer hardware | **+1–3 days** (SD format, wiring, noise) |
| Multi-word audio files | **+1 day** recording/naming |
| Fighting speaker noise in EMG | **+0–several days** if unlucky |

**Smart strategy:**  
Submit idea with speaker in the story.  
Build **signal → “HELP” text** first.  
Add DFPlayer **only after** text trigger is reliable.  
If DFPlayer fights you before video: **fall back to phone TTS** (still a speaker!).

---

# 13) Shopping list to order (copy)

### Now
- [ ] ESP32  
- [ ] AD8232 ×1  
- [ ] Electrodes  
- [ ] Breadboard + jumpers + USB cable  
- [ ] Power bank  
- [ ] Notebook  

### Voice (pick one)
- [ ] **A)** Use phone/laptop only (₹0)  
- [ ] **B)** DFPlayer Mini + microSD + small speaker (~₹300–450)  
- [ ] **C)** Cheap USB/3.5mm PC speaker if demo on laptop  

### Later
- [ ] AD8232 ×2 more  
- [ ] Better strap / optional OLED  

---

# 14) Judge line (with speaker)

> “When the muscle pattern matches HELP with high confidence, the system doesn’t only show text — a speaker says ‘Help’ so a caregiver can hear it immediately.”

---

# 15) Bottom line

| Question | Answer |
|---|---|
| Add speaker? | **Yes for demo value** |
| Hardest speaker path? | Fancy onboard TTS on ESP32 |
| Best speaker path? | **Phone TTS first**, DFPlayer second |
| Does speaker change the EMG science? | No — only the **output stage** |
| Submit idea with speaker mentioned? | **Yes** |
| Build order? | Clean signal → text HELP → **then** speaker |

**You can submit the idea now with speaker in the plan.**  
**You should implement speaker as the last mile of Phase‑1, not the first wire you solder.**
