# VocalBridge — Full Abstract + Multi-AI Honest Feedback Prompt

**Competition:** vivo Ignite 2026 (Grade 8)  
**Theme:** Tech for Good — Transforming Communities Through Technology and Innovation  
**Portal abstract limit:** 150–300 words  
**Idea submission deadline:** 10 July 2026  

---

# PART 1 — PROJECT TITLE

**VocalBridge: Low-Cost Subvocal EMG Communication for Non-Verbal Individuals**

*(Alternate longer title if needed)*  
**VocalBridge: A Low-Cost Multi-Channel Subvocal EMG Communication System for Non-Verbal Individuals Using Edge AI**

---

# PART 2 — PORTAL ABSTRACT (copy-paste ready)

**Word count: 242 (within 150–300)**

People who lose the ability to speak because of ALS, stroke, or vocal-cord damage still send motor signals to the throat and jaw when they try to form words. Professional eye-tracking and speech-generating devices that capture intent cost ₹1,50,000–₹5,00,000 and are out of reach for most Indian families. VocalBridge is a wearable, battery-powered neckband that reads those silent muscle signals (subvocal electromyography) and turns a small set of critical words into speech on a phone.

Three surface electrode channels under the chin and beside the larynx feed low-cost AD8232 amplifiers. An ESP32 samples the signals and streams them over Bluetooth Low Energy. On a laptop or smartphone, a digital pipeline removes 50 Hz interference and movement noise, then a small 1D convolutional network classifies five emergency words: Help, Yes, No, Water, and Pain. A confidence threshold rejects uncertain guesses so the system does not “speak” by mistake. A two-minute personal calibration adapts the model to each new user.

The full prototype is designed to cost under ₹2,500—more than 100× cheaper than commercial AAC hardware—and to be built with parts available in India. The project aligns with UN SDG 3 (Good Health and Well-Being), SDG 10 (Reduced Inequalities), and India’s Accessible India Campaign (Sugamya Bharat Abhiyan). Inspiration is openly acknowledged from research systems such as MIT’s AlterEgo; the student contribution is a multi-channel, low-cost, confidence-gated, India-deployable design with honest scope limits and a clear path to expand vocabulary after the first working demo.

---

# PART 3 — LONGER PROJECT ABSTRACT (for poster / notebook / video voiceover)

*Not for the 300-word portal box. Use for deeper write-ups.*

## 3.1 Problem
Millions of people lose functional speech due to neurodegenerative disease (including ALS), stroke, traumatic injury, or vocal-cord damage. Existing Augmentative and Alternative Communication (AAC) options are often slow (letter boards, eye-gaze typing) or expensive (speech-generating devices commonly in the range of ₹1.5 lakh to several lakhs). For many Indian families—especially outside major cities—real-time assistive speech is effectively inaccessible.

## 3.2 Scientific insight
Even when audible speech is impossible, the brain may still send motor commands to the muscles of the tongue, jaw, and larynx. These residual activations can be measured non-invasively with surface electromyography (sEMG). Silently “mouthing” or attempting a word produces patterns that, for a **small fixed vocabulary**, can be separated with signal processing and machine learning. This is **not** mind-reading and **not** unrestricted continuous speech recognition.

## 3.3 Solution
VocalBridge is a low-cost wearable neckband that:
1. Captures multi-channel surface EMG near submental and laryngeal sites  
2. Amplifies signals with battery-isolated AD8232 front-ends  
3. Digitizes and transmits data with an ESP32 over Bluetooth Low Energy  
4. Filters power-line and motion noise (notch + band-pass + artifact rejection)  
5. Classifies windows of signal with a compact 1D-CNN (or simpler baseline model first)  
6. Speaks the predicted word through phone/laptop TTS **only if confidence is high**

**Prototype vocabulary:** Help, Yes, No, Water, Pain  

## 3.4 Method (pipeline)
Electrodes → AD8232 ×3 → ESP32 ADC (~200 Hz) → BLE →  
Python/app pipeline → 50 Hz notch → band-pass ~20–450 Hz →  
sliding window → classifier → confidence gate → text + speech output  

## 3.5 Innovations (student-level claims)
- Subvocal **word** classification focus (not only fist/open-hand gestures)  
- Multi-channel differential sensing for common-mode noise  
- Confidence-based rejection (wrong speech is worse than silence)  
- Short personal calibration protocol  
- India-retail BOM target under ~₹2,500 vs commercial AAC at ₹1.5L+  

## 3.6 Alignment
- **SDG 3** Good Health and Well-Being  
- **SDG 10** Reduced Inequalities  
- **Sugamya Bharat Abhiyan** (Accessible India Campaign)  

## 3.7 Limitations (must stay in the project story)
- Small vocabulary in v1  
- Per-user calibration needed  
- Sensitive to electrode placement, swallowing, motion  
- Research/education prototype — **not** a certified medical device  
- Safety: battery/power-bank isolation; surface electrodes only; adult supervision  

## 3.8 Time-scoped demo note (if video is soon)
If full 5-word neckband AI is not ready, Phase-1 demo can be:
- reliable single-site muscle intent → HELP / YES  
with multi-word neck array as documented next milestone  
Honesty > broken overclaim.

---

# PART 4 — DETAILED PROMPT FOR OTHER AIs (honest feedback)

Copy **everything inside the box** into ChatGPT / Claude / Gemini / etc.

```
You are a ruthless but fair evaluator for a national student innovation competition in India: vivo Ignite 2026 (Grades 8–12). Theme: "Tech for Good: Transforming Communities Through Technology and Innovation."

Your job is NOT to encourage me, flatter me, or rewrite my idea to sound impressive. Your job is to stress-test the project as if you were:
1) a skeptical engineering mentor,
2) a competition judge who has seen thousands of student projects,
3) a safety reviewer,
4) a student who actually has to build this in limited time.

Be direct. Use plain language. Point out weaknesses even if they hurt. If something is good, say why briefly—but spend more words on risks, holes, and improvements.

========================
PROJECT TO EVALUATE
========================

Title:
VocalBridge: Low-Cost Subvocal EMG Communication for Non-Verbal Individuals

Student level:
Grade 8, India

Team:
Likely 2 students; uneven skills (one stronger technically, one less technical). We will help another friend-team, but this project must stand on its own.

Time constraints:
- Idea submission: poster + 150–300 word abstract (deadline around 10 July 2026).
- A video / prototype demonstration may be required within a few weeks to a couple of months after idea stage (exact later-stage dates may vary). We do NOT have unlimited time.
- Budget target: preferably under ₹2,500–₹4,000 using parts available in India (e.g., ESP32, AD8232, electrodes).

Abstract (portal version):
People who lose the ability to speak because of ALS, stroke, or vocal-cord damage still send motor signals to the throat and jaw when they try to form words. Professional eye-tracking and speech-generating devices that capture intent cost ₹1,50,000–₹5,00,000 and are out of reach for most Indian families. VocalBridge is a wearable, battery-powered neckband that reads those silent muscle signals (subvocal electromyography) and turns a small set of critical words into speech on a phone.

Three surface electrode channels under the chin and beside the larynx feed low-cost AD8232 amplifiers. An ESP32 samples the signals and streams them over Bluetooth Low Energy. On a laptop or smartphone, a digital pipeline removes 50 Hz interference and movement noise, then a small 1D convolutional network classifies five emergency words: Help, Yes, No, Water, and Pain. A confidence threshold rejects uncertain guesses so the system does not “speak” by mistake. A two-minute personal calibration adapts the model to each new user.

The full prototype is designed to cost under ₹2,500—more than 100× cheaper than commercial AAC hardware—and to be built with parts available in India. The project aligns with UN SDG 3 (Good Health and Well-Being), SDG 10 (Reduced Inequalities), and India’s Accessible India Campaign (Sugamya Bharat Abhiyan). Inspiration is openly acknowledged from research systems such as MIT’s AlterEgo; the student contribution is a multi-channel, low-cost, confidence-gated, India-deployable design with honest scope limits and a clear path to expand vocabulary after the first working demo.

Technical plan summary:
- Sensing: 3-channel surface EMG (submental + laryngeal + reference)
- Front-end: AD8232 modules (ECG modules repurposed; known compromise)
- MCU: ESP32, ~200 Hz sampling, BLE to phone/laptop
- DSP: 50 Hz notch, band-pass ~20–450 Hz, artifact rejection for swallow/motion
- ML: small 1D-CNN (or Random Forest baseline first), sliding windows
- Output: on-screen word + TTS only if confidence high (e.g., ≥80%)
- Vocabulary v1: Help, Yes, No, Water, Pain
- Safety stance: battery isolation, surface electrodes only, not a medical device claim
- Prior art: MIT AlterEgo / subvocal research acknowledged; claim is low-cost scoped student system

Competition context:
- Entries may be individual or groups up to 3
- Top ideas shortlisted; later stages involve prototypes/mentoring/finale
- Judges care about innovation, feasibility, social impact, clarity, and whether students truly understand the work
- Common weak entries: generic education apps, simple IoT clones, overclaimed AI, no demo, no limitations

My worries:
- Project may be too complex for Grade 8 in only a few weeks for video
- Signal noise (swallowing, motion, 50 Hz) may destroy accuracy
- AD8232 is for ECG, not ideal EMG
- Team skill imbalance
- Safety questions about electrodes near neck
- Originality doubts because research systems already exist
- Friend team may do a simpler education app and finish faster

========================
WHAT YOU MUST OUTPUT
========================

Respond in the following structure exactly:

## 1. Judge’s first 30-second reaction
What a tired judge thinks after reading the abstract once. Be blunt.

## 2. Overall verdict
Pick ONE:
- Strong Top-200 contender if executed
- Risky but high-upside
- Too ambitious for timeline
- Overclaimed / needs rescope
- Weak / common
Then explain in 5–8 sentences.

## 3. Scorecard (0–10 each, with 1-line justification)
- Novelty vs typical school projects
- Social impact credibility
- Technical depth
- Feasibility for Grade 8 in limited time
- Demo power (if it works)
- Cost/accessibility story
- Safety/ethics readiness
- Clarity of abstract
- Originality honesty (prior art handling)
- Overall competition potential
Also give a total /100.

## 4. Fatal risks (ranked)
List the top 8 ways this project fails in competition or in real build.
For each: probability (Low/Med/High), impact (Low/Med/High), and mitigation.

## 5. Abstract critique
- What sentences help us
- What sentences hurt us / sound AI-generic / overclaim
- Specific edits (show rewritten lines, keep 150–300 words total if you rewrite fully)
- Anything missing that vivo Ignite judges expect

## 6. Scope recommendation for OUR timeline
Assume we may have only a few weeks for a filmable demo.
Tell us:
- What to keep for idea submission
- What to cut from v1 demo
- A Phase-1 minimum viable demo that can still impress
- A Phase-2 stretch goal
Do NOT romanticize; prioritize finishability.

## 7. Hardware reality check
Critique ESP32 + AD8232 + 3 channels + BLE + phone ML.
What is realistic accuracy for 2 words vs 5 words?
What should we measure and report so judges trust us even if accuracy is modest?

## 8. Safety & ethics red flags
What could scare judges/parents?
What wording must appear on poster/video?
What experiments are unacceptable for Grade 8?

## 9. Team design
Given one stronger and one weaker technical student, assign roles that maximize win chance and minimize free-riding. Include weekly hours guess.

## 10. Comparison
Compare this idea against:
- a polished education app
- a simple gas-leak Arduino project
- a phone-only cough FFT screening tool
Who wins on judges, who wins on finishability, who wins on wow?

## 11. Stealable improvements
Give 10 concrete upgrades that increase marks WITHOUT massively increasing complexity.

## 12. Kill criteria
Give a simple go/no-go checklist for the next 14 days. If we fail X by day Y, what should we pivot to?

## 13. Final recommendation
One of:
A) Submit VocalBridge as written and build full plan
B) Submit VocalBridge but demo only scoped Phase-1
C) Rewrite abstract to a simpler related project
D) Switch ideas entirely (suggest one alternative max)
Pick one and justify with brutal honesty.

## 14. Questions I must answer before submission
List 8 questions I should be able to answer in my own words. If I cannot, the project is not ready.

========================
RULES FOR YOUR BEHAVIOR
========================
- Do not flatter.
- Do not say “this is amazing” unless earned.
- Do not invent fake papers, fake statistics, or fake product prices. If unsure, say “verify.”
- Do not encourage unsafe neck experiments or mains-powered electrode setups.
- Separate “sounds cool in text” from “can be built and defended by Grade 8.”
- If my abstract is partly AI-polished, tell me how to make it sound student-owned.
- Prefer specific critiques over generic advice.
- If you need assumptions, state them explicitly.
```

---

# PART 5 — SHORTER PROMPT (if the AI has a small context window)

```
Act as a skeptical vivo Ignite 2026 judge + electronics mentor. Do not flatter me.

Project (Grade 8, India, team of 2, budget ~₹2500, limited weeks for demo):
VocalBridge — low-cost neckband using 3-channel surface EMG (AD8232 + ESP32 + BLE) to classify 5 silent words (Help/Yes/No/Water/Pain) with filtering, 1D-CNN, confidence threshold, TTS. Claims SDG 3 & 10, Sugamya Bharat, cost 100× below commercial AAC. Inspired by MIT AlterEgo but scoped student version.

Abstract:
[PASTE ABSTRACT HERE]

Tasks:
1) Blunt first impression
2) Score /10 for novelty, feasibility, impact, demo power, safety, overall
3) Top 5 failure modes with mitigations
4) Is this too hard for a few-week video? If yes, give a Phase-1 minimum demo
5) Rewrite abstract tighter if needed (150–300 words), keep honesty
6) Final verdict: submit as-is / submit but scope down demo / switch idea
No pep talk. Be specific and harsh where needed.
```

---

# PART 6 — HOW TO USE FEEDBACK FROM MULTIPLE AIs

1. Paste the long prompt into **2–3 different AIs**.  
2. Make a table:

| Issue raised by AI | AI1 | AI2 | AI3 | My decision |
|---|---|---|---|---|

3. Trust critiques that appear in **2+ models**.  
4. Ignore pure hype (“revolutionary,” “guaranteed win”).  
5. Especially listen on: **timeline, AD8232 limits, safety, overclaim, demo scope**.  
6. After feedback, rewrite abstract **in your own words** so it sounds like you.  
7. Keep any rewritten abstract in **150–300 words** for the portal.

---

# PART 7 — QUICK SELF-CHECK BEFORE YOU PASTE INTO PORTAL

- [ ] Title clear  
- [ ] Abstract 150–300 words  
- [ ] Problem + solution + method + cost + SDG present  
- [ ] Vocabulary limited (not “full speech”)  
- [ ] Prior art acknowledged  
- [ ] Limitations / prototype honesty present or ready on poster  
- [ ] You can explain every technical term in one simple sentence  
- [ ] Team roles agreed  
- [ ] Poster file ≤ 5 MB  

---

*Files nearby:*  
- `PORTAL_COPY_PASTE.txt` — same portal abstract  
- `VocalBridge_Master_Package.md` — full technical package  
- `NimitJoshi_Prototype_8thGrade_VocalBridge.pdf` — poster  
