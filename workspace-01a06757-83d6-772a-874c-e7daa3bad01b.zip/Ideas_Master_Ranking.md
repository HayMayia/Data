# vivo Ignite 2026 — Ideas Master Ranking
### All concepts from your chats, ranked for Top 200 → Top 10 potential

**Deadline reminder:** Stage 1 idea submission closes **10 July 2026**.  
**Theme:** Tech for Good — Transforming Communities Through Technology and Innovation  
**Entry types:** Solo / Team of 2 / Team of 3 (max 3)

---

## How this ranking works

Each idea is scored **1–10** on:

| Factor | What it means |
|---|---|
| **Wow / rarity** | Do judges see this every year or almost never? |
| **Social impact** | Real people helped; SDG fit |
| **Technical depth** | Signal processing, ML, sensors, systems thinking |
| **Buildability (Grade 8)** | Can you actually demo something honest? |
| **Demo power** | Live “wow” in front of judges |
| **Cost** | Under ~₹5k preferred |
| **Risk** | Safety, failure modes, overclaim risk |

**Overall** is not a simple average — it weights **demo power + rarity + honest buildability** highest for winning.

---

## TIER S — Best shot at Top 200 / deep run

### 1. VocalBridge (PRIMARY RECOMMENDATION)
**Full title:** Low-Cost Multi-Channel Subvocal EMG Communication for Non-Verbal Individuals  

**One-liner:** A neckband that reads silent throat muscle signals and speaks a few emergency words (Help / Yes / No / Water / Pain).

| Score | |
|---|---|
| Wow / rarity | 9.5 |
| Social impact | 9 |
| Technical depth | 9.5 |
| Buildability | 6.5 (hard but scoped OK) |
| Demo power | 10 |
| Cost | 9 (~₹2k) |
| Risk | 6 (noise, safety narrative) |
| **Overall** | **9.2** |

**Why it wins**
- Rare at school level (gesture EMG is common; **subvocal word class** is not)
- Live demo: mouth “Help” silently → device says “Help”
- Deep stack: sensors + DSP + ML + wearable + accessibility
- Clear SDG 3 + 10 + Sugamya Bharat
- Cost story: ~₹2,000 vs ₹1.5L+ AAC devices

**Must do right**
- Scope to **5 words**, not full sentences  
- Battery isolation safety story  
- Confidence threshold (silence > wrong word)  
- Lab notebook + honest accuracy  
- Cite MIT AlterEgo as inspiration; claim **your** low-cost multi-channel design  

**Team fit**
- **Best as team of 2:** one hardware, one software/ML  
- Solo possible if you are very committed  
- Team of 3 only if third owns video/docs/data collection seriously  

**Status:** Full submission package already built  
→ `PORTAL_COPY_PASTE.txt`  
→ `NimitJoshi_Prototype_8thGrade_VocalBridge.pdf`  
→ `VocalBridge_Master_Package.md`

---

### 2. TactileVision — Haptic Spatial Map for the Blind
**One-liner:** Camera + edge AI describes the room as a **learned vibration language** on a vest/belt — not just “beep for obstacle.”

| Score | |
|---|---|
| Wow / rarity | 8.5 |
| Social impact | 9.5 |
| Technical depth | 8.5 |
| Buildability | 7 |
| Demo power | 8 |
| Cost | 7 (Pi + camera + motors) |
| Risk | 7 |
| **Overall** | **8.4** |

**Pro edge (what makes it not “another blind stick”)**
- Not audio-only (audio blocks hearing)
- **Spatial encoding:** direction + distance + object class as haptic patterns  
- Cognitive map: “door at 2 o’clock, 2 meters” as vibration grammar  
- Compare vs Microsoft Seeing AI / smart canes — your gap is **non-audio spatial language**

**Architecture**
```
Phone/ESP-CAM → object/depth estimate → encoding rules
→ haptic array (4–8 vibromotors on belt/vest)
→ user training protocol (15 min learnable patterns)
```

**SDG:** 3, 10 · Sugamya Bharat  
**BOM rough:** ₹3,000–6,000  
**Risk:** Judges have seen many blind aids — must stress **haptic language novelty**  
**Best as:** Team of 2–3 (CV + hardware + user testing docs)

**When to pick this over VocalBridge**
- You hate neck electrodes / safety anxiety  
- Your team is stronger at cameras/apps than analog sensors  
- Week-2 EMG signal fails → **this is the planned pivot**

---

## TIER A — Strong Top 200 candidates

### 3. Audio-Biomarker Respiratory Screen (phone only)
**One-liner:** Smartphone mic + FFT finds cough/breath “digital biomarkers” for early respiratory screening (not a hospital diagnosis claim).

| Overall | **8.0** |
| Cost | ₹0 hardware |
| Demo | Spectrogram of cough vs normal; simple classifier |
| Risk | Medical overclaim — frame as **screening research tool**, not doctor |

**Why it can place:** Software-only, scalable for rural India, real DSP (FFT peaks, MFCCs, simple ML).  
**SDG:** 3  
**Team:** Solo or 2 perfect  
**Weakness:** Less “hardware wow” than VocalBridge; many health apps exist — win on **signal viz + honest clinical limits**

---

### 4. Spec-Detect — Low-Cost Spectral Food/Medicine Adulteration Check
**One-liner:** Handheld AS726x spectral sensor builds a “fingerprint” of pure milk/oil and flags adulteration curves.

| Overall | **7.8** |
| Cost | ₹2,000–4,000 |
| Demo | Pure milk vs urea-spiked sample → red/green |
| Risk | Chemistry validity; need careful calibration claims |

**Pro edge:** Materials science, not “pH strip project.”  
**SDG:** 3, 12  
**Team:** 2 (chem protocol + electronics)

---

### 5. Smart Greywater Diversion
**One-liner:** Turbidity + pH + conductivity decide: sink water → garden OR sewer; dashboard tracks liters saved.

| Overall | **7.5** |
| Cost | ₹2,500–4,000 |
| Demo | Dirty vs clean water auto-valve path |
| Risk | Looks “ordinary IoT” unless ML prediction + clean housing |

**Pro edge:** Classification + diversion + **regression forecast** of savings, not just a filter.  
**SDG:** 6, 11, 12 · Smart Cities  
**Team:** 2–3

---

### 6. Edge-AI Leaf Physician
**One-liner:** ESP32-CAM on-device model detects early crop disease/nutrient stress for small farmers.

| Overall | **7.4** |
| Cost | ₹1,500–3,000 |
| Demo | Leaf photo → deficiency/disease label + confidence |
| Risk | “Another plant app” — must be **on-device / offline** for farms |

**SDG:** 2, 15  
**Pro edge:** Quantized NN on edge, not cloud-only.

---

## TIER B — Good, but crowded or harder to win 1st

### 7. Piezo / Thermo Micro-Energy Harvesting
Footstep or stove-heat → emergency LED / sensor power.  
**Overall ~6.8** — physics-nice, demo often weak (tiny power), hard to look “product.”

### 8. AI Algal Bio-Scrubber for Effluent
Algae + sensors + camera density ML for dye/metal cleanup.  
**Overall ~7.0** — huge impact story, **slow biology demos**, hard in school timeline.

### 9. Hybrid: VocalBridge + Silent Emergency Commands
Same EMG core; secondary story for firefighters/noisy disaster zones.  
**Overall ~8.3 as narrative upgrade to #1** — do **not** build two products; keep primary = non-verbal patients.

### 10. Wildfire / Smoke Infrastructure Vision
Camera smoke detect at scale.  
**Overall ~6.5 for student demo** — great as nation-scale idea, weak as “what did *this student* build?” (chat already warned this).

---

## Head-to-head: what should YOU submit?

```
                    HIGH DEMO WOW
                         │
         VocalBridge ●   │
                         │  ● TactileVision
                         │
    RARE ───────────────┼─────────────── COMMON
                         │
         Spec-Detect ●   │  ● Leaf AI
                         │  ● Greywater
              Audio ●    │
                         │
                    EASIER BUILD
```

### Decision tree

1. **Can you commit ~10 weeks + ~₹2k + learn Python/Arduino?**  
   - **Yes** → **Submit VocalBridge** (best overall win path)  
   - **No** → Audio-Biomarker or Leaf Physician  

2. **Is neck/EMG safety making you or parents uncomfortable?**  
   - **Yes** → **TactileVision** or **Audio-Biomarker**  

3. **Team of 2 with one coder + one hardware person?**  
   - **Yes** → VocalBridge or Spec-Detect  

4. **Team of 3, one is presentation-only?**  
   - Still OK if two builders are solid; don’t add a third “for luck”

---

## Deeper cards for top alternates

### A) TactileVision — submission skeleton

**Title:** TactileVision: A Wearable Haptic Spatial Language System for Visually Impaired Navigation  

**Problem:** Audio-based aids block environmental hearing; canes miss overhead/side context; expensive smart glasses aren’t accessible.

**Solution:** Belt/vest with vibromotor grid; phone/ESP-CAM runs lightweight detection; maps:
- Left / center / right  
- Near / mid / far  
- Person / vehicle / door / stairs (start with 3–4 classes)

**Innovations**
1. Non-audio primary channel  
2. Trainable haptic “grammar”  
3. Offline-first for Indian streets  
4. Cost target under ₹5,000  

**Abstract seed (shorten to 150–300 words if you switch):**  
Visually impaired pedestrians need spatial awareness without blocking hearing. TactileVision converts camera-based scene understanding into a compact vibration language on a wearable belt. An edge device estimates direction and distance of key obstacles and landmarks, then drives a small motor array using fixed patterns the user learns in minutes. Unlike simple ultrasonic beeps, the system encodes structured spatial messages and works offline. Prototype cost targets under ₹5,000. Aligns with SDG 3, SDG 10, and Sugamya Bharat Abhiyan.

---

### B) Audio-Biomarker — submission skeleton

**Title:** RespiSense: Smartphone Acoustic Biomarkers for Community Respiratory Screening  

**Problem:** Late detection of asthma/COPD-like issues in rural areas with few specialists.

**Solution:** Phone mic → record cough/breath → FFT + features → risk score + visualization.  
**Hard rule:** “Decision support / screening research,” **not** diagnosis.

**Innovations**
1. Zero extra hardware  
2. Frequency visualization judges can see  
3. On-device or lightweight model  
4. Dataset protocol + ethics (consent)

---

### C) Spec-Detect — submission skeleton

**Title:** Spec-Detect: Low-Cost Multispectral Fingerprinting Against Food Adulteration  

**Problem:** Milk/oil adulteration; lab tests slow/expensive.

**Solution:** AS7262/AS7263 + controlled light box + spectral library + simple classifier.  
**Demo:** side-by-side pure vs adulterated sample.

---

## What “Top 200 quality” always needs (any idea)

1. **Specific problem + Indian/local stat** (not “pollution is bad”)  
2. **SDG number + national scheme** (Sugamya Bharat / Smart Cities / etc.)  
3. **Block diagram** on poster  
4. **BOM with ₹**  
5. **Limitations** written honestly  
6. **Future scope** one paragraph  
7. **Your contribution** vs prior art  
8. **Working or partial prototype plan** with milestones  

---

## Recommended path from here

### Tonight (mandatory if not submitted)
Submit **VocalBridge** using existing files — strongest package you already have.

### This week
1. Confirm team: **solo / 2 / 3** with written roles  
2. Order BOM only if shortlisted or you want head start (~₹2,050 Option A)  
3. Start **handwritten lab notebook**  
4. Keep **TactileVision** as official Plan B if EMG signals fail Week 2  

### Do not do
- Submit 3 half-baked ideas  
- Switch ideas every day  
- Claim full speech synthesis / curing blindness / medical diagnosis  

---

## Quick pick table for your friends’ argument

| If priority is… | Pick |
|---|---|
| Highest ceiling / 1st-place energy | **VocalBridge** |
| Safer demo + accessibility | **TactileVision** |
| Zero hardware cost | **Audio-Biomarker** |
| Chemistry / consumer safety | **Spec-Detect** |
| Environment / Smart Cities | **Greywater** |
| Agriculture | **Leaf Physician** |
| Best for team of 2 builders | **VocalBridge** or **Spec-Detect** |
| Best for solo software kid | **Audio-Biomarker** |
| Best if third person is only “extra” | Stay **2**, idea unchanged |

---

## Bottom line

**Continue means: lock VocalBridge as primary, keep TactileVision as engineered backup, and stop idea-shopping.**

You already have the deepest, rarest, highest-demo idea developed across the whole chat history. The competition from here is **execution and ownership**, not finding a magical 11th concept.

**Files to use now**
1. `PORTAL_COPY_PASTE.txt` — title + abstract  
2. `NimitJoshi_Prototype_8thGrade_VocalBridge.pdf` — poster  
3. `VocalBridge_Master_Package.md` — full technical plan  
4. `Ideas_Master_Ranking.md` — this file (all ideas ranked)

If you want next: I can generate a **full poster + abstract for TactileVision or RespiSense** as backup, or a **1-page comparison poster** “Why VocalBridge over common school projects.”
