# VocalBridge — Complete vivo Ignite 2026 Submission Package
### Grade 8 | Theme: Tech for Good — Transforming Communities Through Technology and Innovation

**CRITICAL DEADLINE:** Stage 1 Idea Submission closes **10 July 2026**  
**Today’s date (your local time):** 9 July 2026 — **submit today / before the portal cutoff.**

**What this package contains**
1. Ready-to-paste **Title + Abstract** (150–300 words) for the portal  
2. **Digital poster** (landscape PDF + PNG) ready to upload  
3. Full **idea write-up** (problem → science → architecture → budget → SDGs)  
4. **Materials list** with India pricing  
5. **10-week build plan** (for after shortlisting)  
6. **Safety, originality, and authenticity** answers  
7. **Video / interview** talking points  

---

## 1. PORTAL FIELDS (copy carefully)

### Project Title
**VocalBridge: Low-Cost Subvocal EMG Communication for Non-Verbal Individuals**

*(Portal filename for poster — replace YOURNAME with your real name, no spaces):*  
`YOURNAME_Prototype_8thGrade_VocalBridge.pdf`

### Category / Theme angle
Assistive technology · Healthcare · Soft-tech for social good · Accessibility  

### Abstract (249 words — within 150–300)

People who lose the ability to speak because of ALS, stroke, or vocal-cord damage still send motor signals to the throat and jaw when they try to form words. Professional eye-tracking and speech-generating devices that capture intent cost ₹1,50,000–₹5,00,000 and are out of reach for most Indian families. VocalBridge is a wearable, battery-powered neckband that reads those silent muscle signals (subvocal electromyography) and turns a small set of critical words into speech on a phone.

Three surface electrode channels under the chin and beside the larynx feed low-cost AD8232 amplifiers. An ESP32 samples the signals and streams them over Bluetooth Low Energy. On a laptop or smartphone, a digital pipeline removes 50 Hz interference and movement noise, then a small 1D convolutional network classifies five emergency words: Help, Yes, No, Water, and Pain. A confidence threshold rejects uncertain guesses so the system does not “speak” by mistake. A two-minute personal calibration adapts the model to each new user.

The full prototype is designed to cost under ₹2,500—more than 100× cheaper than commercial AAC hardware—and to be built with parts available in India. The project aligns with UN SDG 3 (Good Health and Well-Being), SDG 10 (Reduced Inequalities), and India’s Accessible India Campaign (Sugamya Bharat Abhiyan). Inspiration is openly acknowledged from research systems such as MIT’s AlterEgo; the student contribution is a multi-channel, low-cost, confidence-gated, India-deployable design with honest scope limits and a clear path to expand vocabulary after the first working demo.

---

## 2. FULL IDEA WRITE-UP (use for poster text, notebook, video script)

### 2.1 Problem
- Millions of people in India live with speech disability after neurological disease or injury.
- Existing Augmentative and Alternative Communication (AAC) options are either:
  - **Slow** (letter boards, eye-gaze typing), or  
  - **Expensive** (speech-generating devices often ₹1.5 lakh–several lakhs).
- Rural and low-income families are effectively locked out of real-time communication.
- Even when someone cannot produce sound, the brain still tries to drive the **submental**, **laryngeal**, and **lip/jaw** muscles. Those micro-movements are measurable.

### 2.2 Core scientific insight
**Subvocalization** = silently “saying” a word in your mind while the speech muscles still fire very slightly.  
Surface EMG electrodes on the skin can pick up those microvolts. Different words create different multi-channel patterns. Machine learning can learn those patterns for a **small, fixed vocabulary**.

This is **not** mind-reading and **not** full continuous speech. It is pattern recognition of residual muscle activity for a few life-critical words.

### 2.3 Proposed solution — VocalBridge
A soft neckband that:

1. Captures **3-channel differential EMG** from throat/jaw placement sites  
2. Amplifies with **AD8232** modules (repurposed ECG front-ends, battery-isolated)  
3. Digitizes and wirelessly sends data with an **ESP32** (BLE)  
4. Cleans the signal (notch + band-pass + artifact reject)  
5. Classifies with a **1D-CNN** (or Random Forest as a simpler baseline)  
6. Speaks the word aloud via **text-to-speech** only if confidence ≥ ~80%

**Initial vocabulary (prototype):** Help · Yes · No · Water · Pain  

These five cover emergency and basic needs. Expanding vocabulary is future work, not a claim for Version 1.

### 2.4 Technical architecture

```
[ Submental electrode pair ]  ─┐
[ Laryngeal electrode pair  ] ─┼─► [ AD8232 ×3 ] ─► [ ESP32 ADC @ ~200 Hz ]
[ Reference on bony area    ] ─┘                              │
                                                              ▼
                                                    [ BLE wireless link ]
                                                              │
                                                              ▼
                              [ Python / app pipeline on phone or laptop ]
                              • 50 Hz notch filter
                              • Band-pass ~20–450 Hz (EMG band)
                              • Rectify + envelope / feature extract
                              • Swallow / motion artifact rejection
                              • Sliding window (e.g. 500 ms, step 100 ms)
                              • 1D-CNN classifier + confidence gate
                                                              │
                                                              ▼
                                              [ On-screen word + TTS voice ]
```

### 2.5 Key innovations (what makes this more than “another EMG project”)
1. **Subvocal word classification**, not fist-open hand gestures or simple on/off EMG  
2. **Multi-channel differential sensing** to fight common-mode noise (mains, motion)  
3. **Confidence-based rejection** — silence is better than a wrong word  
4. **2-minute personal calibration** so it can work for more than one person  
5. **India-priced BOM under ~₹2,500** vs commercial AAC at ₹1.5 lakh+  
6. Honest **5-word scope** with a documented expansion path  

### 2.6 SDG & national alignment
| Alignment | How VocalBridge connects |
|---|---|
| **SDG 3** Good Health and Well-Being | Restores basic communication for people with speech loss; supports Target 3.8 (access to health services) |
| **SDG 10** Reduced Inequalities | Cuts cost by ~100× so assistive tech is not only for the wealthy |
| **Sugamya Bharat Abhiyan** | Digital/physical accessibility for Persons with Disabilities (PwDs) in India |
| **Theme: Tech for Good** | Deep-tech (biosignals + edge AI) applied to a community problem |

### 2.7 Budget (starter BOM — India retail, approx.)

| Item | Qty | Approx. ₹ | Source |
|---|---:|---:|---|
| ESP32 DevKit | 1 | 350 | Robu.in / Amazon |
| AD8232 ECG/EMG module | 3 | 750 | Robu.in |
| Disposable ECG electrodes (pack) | 1 | 250 | Medical store / Amazon |
| Breadboard + jumper wires | 1 set | 150 | Robu.in |
| LiPo 3.7 V + TP4056 charger | 1 | 250 | Robu.in |
| Elastic / neoprene strap + Velcro | 1 | 150 | Local / Amazon |
| USB cable, headers, misc. | — | 150 | Local |
| **Starter total** | | **~₹2,050** | |
| Optional upgrade: ADS1115 16-bit ADC | 1 | +280 | Robu.in |
| Optional: reusable Ag/AgCl electrodes | 1 set | +600 | Amazon |

**Software (free):** Arduino IDE, Python 3, NumPy, SciPy, scikit-learn, TensorFlow/Keras, Matplotlib.

### 2.8 Timeline (after shortlisting — 10 weeks)

| Weeks | Milestone |
|---|---|
| 1–2 | Assemble hardware; verify raw EMG while silently mouthing words |
| 3–4 | Collect dataset (many repetitions × 5 words); keep lab notebook |
| 5 | Signal processing: filters, features, artifact rules |
| 6–7 | Train baseline RF + 1D-CNN; report honest accuracy + confusion matrix |
| 8 | Real-time BLE demo + TTS |
| 9 | Calibration mode + confidence threshold |
| 10 | Enclosure polish, poster/video, Q&A practice |

**Decision gates (important):**  
- End of Week 2: clean, word-related signal visible? If **no** → fix placement or pivot.  
- End of Week 5: classes separable in feature space? If **no** → reduce to 2–3 words.  
- Never hide failures — document them.

### 2.9 Safety (must be stated in poster & interview)
- **Battery-only / power-bank isolation** while electrodes touch skin — never mains-powered laptop USB as sole isolation plan.  
- Low voltage; electrodes on **skin surface only** (no needles).  
- Avoid pressing hard on carotid region; place on muscle sites taught by self-tests (submental triangle, beside Adam’s apple, bony reference).  
- Prototype is a **research demo**, not a certified medical device.  
- Human testing: self first; any other person only with informed consent and adult supervision.

### 2.10 Limitations (honesty wins marks)
- Vocabulary limited to 5 words in V1  
- Needs per-user calibration  
- Sensitive to electrode placement and swallowing artifacts  
- Not a replacement for clinical AAC without clinical validation  

### 2.11 Future scope
- Larger vocabulary and multi-user transfer learning  
- TensorFlow Lite Micro on-device inference (no laptop)  
- Smart-home / emergency alert integration  
- Partnership with speech-language pathologists for ethical validation  

### 2.12 Prior art & originality statement (use this honesty)
Inspired by research such as **MIT AlterEgo** and NASA subvocal experiments. Those systems are lab-grade and expensive.  
**Student contribution:** low-cost multi-channel design, India-available parts, confidence gating, personal calibration, and a competition-ready scoped vocabulary with full documentation of failures and metrics.  
EMG **gesture** projects are common; **subvocal word classification** at school level is rare.

---

## 3. BUILDING THE PROTOTYPE — WHAT TO LEARN

### Muscle sites (self-test before buying)
1. **Submental (under chin):** silently mouth “help” — feel tightening.  
2. **Laryngeal (beside Adam’s apple):** silently mouth “water” — slight motion.  
3. **Swallow test:** swallow is *much* larger — this is why artifact rejection exists.

### Signal pipeline (concepts you must explain in your own words)
- **EMG** = electrical activity of muscles  
- **Differential measurement** = measure difference between two electrodes to cancel shared noise  
- **50 Hz notch** = remove power-line hum in India  
- **Band-pass 20–450 Hz** = keep muscle signal, drop slow motion and high-frequency junk  
- **FFT** (optional feature) = “break the wave into musical notes” to see frequency energy  
- **Sliding window** = look at short chunks continuously so response feels live  
- **Confidence threshold** = if the model is unsure, stay silent  
- **Cross-validation / confusion matrix** = honest way to measure accuracy  

### Realistic accuracy targets (do not oversell)
- 2 words: often achievable with care  
- 5 words: ambitious; report real numbers (even 50–70% with clear analysis can win if science is solid)  
- Always show **what went wrong** and **Version 2 plan**

---

## 4. AUTHENTICITY — PROVE IT IS YOURS

Start **today**:
1. **Handwritten lab notebook** — date, plan, what happened, what failed, next step  
2. Photos of sketches, breadboard, electrode placement experiments  
3. Explain one hard idea simply on camera without notes (e.g. why 20–450 Hz)  
4. Practice answer if asked “Did AI / a teacher build this?”:  
   > “I used books, tutorials, and AI to **learn** concepts the way students use textbooks. I designed the scope, ran the experiments, collected the data, and can explain every block and every failure myself.”

---

## 5. VIDEO / JUDGE Q&A CHEAT SHEET

**30-second hook**  
“Even when someone cannot speak, their throat muscles still try. VocalBridge listens to those silent signals and speaks five emergency words for them — for about the price of a school textbook set, not a luxury medical device.”

**Demo story**  
Wear band → silently mouth “Help” → screen/TTS says “Help”.

**Likely questions**
- Why not just use a microphone? → Target users cannot produce usable sound.  
- Why 5 words? → Scientific rigor; emergency coverage first.  
- Why not full sentences? → That needs years of lab work; we scope like real researchers.  
- Safety? → Battery isolation, surface electrodes, adult supervision, not a medical claim.  
- What if accuracy is low? → We publish the confusion matrix, reduce vocabulary, improve placement — engineering is iteration.

---

## 6. SUBMIT CHECKLIST (TONIGHT)

- [ ] Register / log in at https://vivoignite.com/  
- [ ] Parental approval completed  
- [ ] Title entered exactly as above (or your slight personal wording)  
- [ ] Abstract 150–300 words pasted (use Section 1)  
- [ ] Poster uploaded: JPEG/PNG/PDF, **under 5 MB**, English, static images only  
- [ ] Filename: `YourName_Prototype_8thGrade_VocalBridge.pdf`  
- [ ] No celebrity / government official photos  
- [ ] Preview → Submit **before 10 July 2026 cutoff**  
- [ ] Save confirmation email / screenshot  

**Note:** `Hey! What's up.pdf` in your uploads appears corrupted (blank pages / broken streams). All recoverable content for this package came from `claude-sonnet-5-high.pdf` (read bottom→top as you instructed) plus official vivo Ignite guidelines.

---

## 7. AFTER YOU SUBMIT

1. Order Option A parts (~₹2,050) only if shortlisted or if you want a head start.  
2. Keep the lab notebook daily.  
3. Week-2 signal check is the real go/no-go.  
4. Backup narrative if needed: same EMG skills can power **silent emergency commands** (e.g. for noisy disaster sites) — keep communication for non-verbal users as the primary story.

---

*Built by combining every strong idea, constraint, and technical decision from your prior chats into one competition-ready package. Rewrite any sentence in your own voice before final submit so it sounds like you.*
