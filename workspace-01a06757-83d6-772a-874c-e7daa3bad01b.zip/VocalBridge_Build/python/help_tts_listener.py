"""
VocalBridge Phase-1 — Speak "Help" when ESP32 prints HELP

Setup (Windows/Mac/Linux):
  1) pip install pyserial pyttsx3
  2) Close Arduino Serial Monitor/Plotter (only one app can use the port)
  3) python help_tts_listener.py COM5        # Windows example
     python help_tts_listener.py /dev/ttyUSB0  # Linux example

The ESP32 must be running VocalBridge_Phase1_HELP.ino
Prefer PRINT_DEBUG = false in the Arduino sketch for cleaner parsing.
"""

import sys
import time

def main():
    if len(sys.argv) < 2:
        print("Usage: python help_tts_listener.py <SERIAL_PORT>")
        print("Example: python help_tts_listener.py COM5")
        sys.exit(1)

    port = sys.argv[1]
    baud = 115200

    try:
        import serial
    except ImportError:
        print("Missing pyserial. Run: pip install pyserial")
        sys.exit(1)

    # TTS engine
    speak = None
    try:
        import pyttsx3
        engine = pyttsx3.init()
        engine.setProperty("rate", 170)

        def speak(text: str):
            engine.say(text)
            engine.runAndWait()

        print("TTS engine: pyttsx3 OK")
    except Exception as e:
        print("pyttsx3 not available (", e, ") — will only print HELP")

        def speak(text: str):
            print("[TTS fallback]", text)

    print(f"Opening {port} @ {baud} ...")
    ser = serial.Serial(port, baud, timeout=1)
    time.sleep(2)  # ESP32 reset on open
    print("Listening for HELP lines. Ctrl+C to stop.")

    try:
        while True:
            line = ser.readline().decode("utf-8", errors="ignore").strip()
            if not line:
                continue
            # Show non-debug traffic lightly
            if line.startswith("DEBUG"):
                continue
            print("SERIAL:", line)
            if line.upper() == "HELP" or line.upper().endswith("HELP"):
                print(">>> Detected HELP — speaking")
                speak("Help")
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        ser.close()


if __name__ == "__main__":
    main()
