# VocalBridge_Build — Phase-1 kit

Everything to **physically build** VocalBridge Phase-1 (rest vs HELP).

## Start here
1. Read `docs/01_BUILD_GUIDE.md`
2. Buy materials list in that guide
3. Wire using `wiring/WIRING.txt`
4. Upload Arduino sketches in order:
   - `arduino/VocalBridge_Phase1_Plotter/`
   - `arduino/VocalBridge_Phase1_HELP/`
5. Optional speech: `python/help_tts_listener.py`
6. Fill `docs/02_CALIBRATION_SHEET.md` and use `docs/03_LAB_NOTEBOOK_TEMPLATE.md`
7. If Top 200: `docs/04_VIDEO_SCRIPT.md`
8. Schedule: `docs/05_DAY_BY_DAY_14_DAYS.md`

## Phase-1 success
- Live graph shows rest ≠ action  
- Serial prints `HELP` on intentional action  
- Optional: computer says “Help”  
- Notebook has real trial counts  
- You can explain AD8232 honesty + silence-on-unsure  

## Not Phase-1
- Perfect 5-word model  
- Medical claims  
- Dual ±9V complex EMG boards (unless you already mastered basics)
