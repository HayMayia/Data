/*
 * VocalBridge Phase-1 — Signal Plotter
 * ------------------------------------
 * Purpose: See live EMG-like / biopotential signal from AD8232 on Serial Plotter.
 *
 * Board: ESP32 Dev Module
 * Wiring: AD8232 OUTPUT -> GPIO34, 3.3V -> 3V3, GND -> GND
 * Baud: 115200
 *
 * Usage:
 *  1) Upload this sketch
 *  2) Tools -> Serial Plotter (115200)
 *  3) Rest arm, then clench fist / mouth HELP
 *  4) Write typical REST and ACTION values in your notebook
 */

const int EMG_PIN = 34;          // ESP32 ADC1 pin (input only)
const int SAMPLE_DELAY_MS = 5;   // ~200 Hz print rate (good enough for viewing)

// Optional simple smoothing (moving average of N samples)
const int SMOOTH_N = 8;

void setup() {
  Serial.begin(115200);
  delay(500);

  // ESP32 ADC settings (helps stability a bit)
  analogReadResolution(12);          // 0..4095
  analogSetPinAttenuation(EMG_PIN, ADC_11db); // wider input range

  Serial.println("VocalBridge_Phase1_Plotter");
  Serial.println("Open Serial Plotter. Columns: raw,smooth");
}

void loop() {
  long sum = 0;
  int raw = 0;

  for (int i = 0; i < SMOOTH_N; i++) {
    raw = analogRead(EMG_PIN);
    sum += raw;
    delayMicroseconds(300);
  }

  int smooth = (int)(sum / SMOOTH_N);

  // Serial Plotter format: value1,value2
  Serial.print(raw);
  Serial.print(',');
  Serial.println(smooth);

  delay(SAMPLE_DELAY_MS);
}
