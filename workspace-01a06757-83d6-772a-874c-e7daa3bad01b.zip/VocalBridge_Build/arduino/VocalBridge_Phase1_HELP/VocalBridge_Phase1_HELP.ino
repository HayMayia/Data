/*
 * VocalBridge Phase-1 — HELP Detector (threshold)
 * -----------------------------------------------
 * Purpose:
 *   Detect intentional muscle burst vs rest and print HELP once per event.
 *
 * Board: ESP32 Dev Module
 * Wiring: AD8232 OUTPUT -> GPIO34, 3.3V -> 3V3, GND -> GND
 * Baud: 115200
 *
 * HOW TO SET THRESHOLD:
 *   1) Run VocalBridge_Phase1_Plotter first
 *   2) Note REST typical smooth values and ACTION peaks
 *   3) Set THRESHOLD between them
 *      Example: rest ~500, action ~1500 -> try THRESHOLD 900
 *   4) If false HELP while idle -> RAISE threshold
 *   5) If real action never triggers -> LOWER threshold or fix electrodes
 *
 * Output lines:
 *   HELP          -> intentional detection (for humans + Python TTS)
 *   DEBUG,...     -> optional live values (comment out if noisy)
 */

const int EMG_PIN = 34;

// ====== CALIBRATE THESE ======
int THRESHOLD = 900;           // <<< CHANGE after Plotter calibration
const int WINDOW_SAMPLES = 40; // samples per decision window
const int SAMPLE_GAP_US = 2000;// spacing inside window (~20 ms * 40 ~= 80 ms + overhead)
const int DEBOUNCE_MS = 180;   // must stay above threshold this long
const int COOLDOWN_MS = 1500;  // ignore new triggers after HELP
const bool PRINT_DEBUG = true; // set false for cleaner Serial for TTS script
// =============================

unsigned long aboveSince = 0;
bool aboveActive = false;
unsigned long lastHelpMs = 0;

void setup() {
  Serial.begin(115200);
  delay(500);

  analogReadResolution(12);
  analogSetPinAttenuation(EMG_PIN, ADC_11db);

  Serial.println("VocalBridge_Phase1_HELP");
  Serial.print("THRESHOLD=");
  Serial.println(THRESHOLD);
  Serial.println("Ready. Perform action to trigger HELP.");
}

int readFeature() {
  // Feature: mean absolute deviation around mean (burst energy-ish)
  // Works better than raw average alone for some noisy baselines.
  long sum = 0;
  int buf[WINDOW_SAMPLES];

  for (int i = 0; i < WINDOW_SAMPLES; i++) {
    int v = analogRead(EMG_PIN);
    buf[i] = v;
    sum += v;
    delayMicroseconds(SAMPLE_GAP_US);
  }

  int mean = (int)(sum / WINDOW_SAMPLES);
  long madSum = 0;
  for (int i = 0; i < WINDOW_SAMPLES; i++) {
    int d = buf[i] - mean;
    if (d < 0) d = -d;
    madSum += d;
  }
  int mad = (int)(madSum / WINDOW_SAMPLES);

  // Also track peak mean level as secondary (printed in debug)
  // Final feature used for threshold: blend
  int feature = mad * 2 + (mean / 8);
  return feature;
}

void loop() {
  int feature = readFeature();
  unsigned long now = millis();

  if (PRINT_DEBUG) {
    Serial.print("DEBUG,feature=");
    Serial.print(feature);
    Serial.print(",thr=");
    Serial.println(THRESHOLD);
  }

  bool above = feature > THRESHOLD;

  if (above) {
    if (!aboveActive) {
      aboveActive = true;
      aboveSince = now;
    } else if ((now - aboveSince) >= (unsigned long)DEBOUNCE_MS) {
      if ((now - lastHelpMs) >= (unsigned long)COOLDOWN_MS) {
        Serial.println("HELP");
        lastHelpMs = now;
        aboveSince = now; // prevent immediate re-fire inside same burst handling
      }
    }
  } else {
    aboveActive = false;
    aboveSince = 0;
  }
}
