/*
 * VocalBridge — SIMPLE MUSCLE MOVEMENT TEST
 * -----------------------------------------
 * Purpose: ONLY check if AD8232 + electrodes + ESP32 are working.
 * No HELP word logic. No speaker. No ML.
 *
 * Board:  ESP32 Dev Module
 * Wiring:
 *   AD8232 3.3V  -> ESP32 3V3
 *   AD8232 GND   -> ESP32 GND
 *   AD8232 OUTPUT-> ESP32 GPIO34
 *
 * Electrodes (forearm first):
 *   2 pads on forearm muscle (a few cm apart)
 *   1 reference pad on elbow bone
 *   (follow YOUR cable colors from the kit)
 *
 * How to use:
 *   1) Select Board: ESP32 Dev Module
 *   2) Select correct COM port
 *   3) Upload this sketch
 *   4) Tools -> Serial Plotter  (baud 115200)
 *   5) Sit still (rest)     -> line should be relatively steady
 *   6) Clench fist hard     -> line should jump / change a lot
 *   7) Relax                -> line should fall back
 *
 * If you see clear rest vs clench difference = HARDWARE WORKS.
 */

const int SENSOR_PIN = 34;   // AD8232 OUTPUT -> GPIO34
const int BAUD = 115200;

void setup() {
  Serial.begin(BAUD);
  delay(800);

  analogReadResolution(12);                 // 0..4095 on ESP32
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);

  // One-time text (Serial Monitor). For Plotter, ignore these first lines.
  Serial.println("VocalBridge_MuscleTest");
  Serial.println("Open Serial Plotter @ 115200");
  Serial.println("Rest, then clench fist.");
}

void loop() {
  // Light smoothing so the plot is readable
  long sum = 0;
  const int N = 10;
  for (int i = 0; i < N; i++) {
    sum += analogRead(SENSOR_PIN);
    delayMicroseconds(500);
  }
  int value = (int)(sum / N);

  // Serial Plotter needs a plain number each line
  Serial.println(value);

  delay(10);  // ~100 updates/sec, easy to see
}
