# Lab notebook — session template

Copy one block per work session (or write in a physical notebook).

---

**Date:**  
**Start–end time:**  
**People present:**  
**Goal today:**  

## Plan
- 

## What we actually did
- 

## Wiring / placement
- ESP32 pin used: GPIO34 (or ____)
- Electrode positions:
- Power: USB laptop / power bank

## Observations
- Rest signal looked like:
- Action signal looked like:
- Threshold tried:
- False triggers:
- Missed detections:

## Data counts
- REST trials: ____
- HELP/action trials: ____
- False HELP: ____
- Missed HELP: ____

## Problems
1. 
2. 

## Fixes tried
1. 
2. 

## Result today
- [ ] Blink works
- [ ] Plotter shows rest vs action
- [ ] HELP prints on Serial
- [ ] TTS speaks Help
- [ ] Demo filmed

## Next session
- 

## Photos saved
- wiring: Y/N
- plotter: Y/N
- placement: Y/N
