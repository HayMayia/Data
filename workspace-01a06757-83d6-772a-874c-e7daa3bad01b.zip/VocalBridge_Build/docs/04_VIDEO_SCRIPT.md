# Top 200 video script (60–90 seconds)

## Shot list
1. Both faces + names (5s)
2. Problem (15s) — teammate can speak
3. Live demo (30–40s) — you run tech
4. How it works simply (15s)
5. Cost + not medical device (10s)
6. End card names/school/title (5s)

## Words (example)

**Teammate:**  
“Many people cannot speak after stroke or similar conditions. Good devices can cost over a lakh rupees. We are building VocalBridge — a low-cost way to detect emergency intent from residual muscle activity.”

**You:**  
“Here are the electrodes and ESP32. At rest the signal is low. When I attempt Help, the signal rises. Our code crosses a calibrated threshold and prints HELP.”  
*(do live demo)*  
“The computer can also say Help out loud for a caregiver.”

**Either:**  
“This is a student prototype, not a medical device. Phase-1 is Help versus rest. Next we improve filtering and add more words carefully. Cost is about two thousand rupees in parts.”

## Rules of a good take
- Quiet room, bright table, wires visible but neat
- One successful HELP in frame
- Say limits out loud
- No background music needed
- Film 5 takes, pick best
