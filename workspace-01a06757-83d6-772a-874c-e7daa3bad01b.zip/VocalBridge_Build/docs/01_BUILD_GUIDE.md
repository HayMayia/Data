# VocalBridge Phase-1 — Build Guide (Materials, Wiring, Code, Calibration)

**Goal of Phase-1:**  
Rest vs intentional muscle action → computer shows **HELP** and can speak “Help”.

**Not the goal yet:** full 5-word neck AI, perfect medical device, multi-user clinical accuracy.

**Results tomorrow (Top 200):** keep building either way. If selected, you need a working demo video soon. If not, this still feeds IRIS.

---

## 0) Safety (read before any skin test)

1. **Surface electrodes only** (sticky pads). No needles.
2. Prefer **power bank** power when pads are on skin (not careless wall-mains setups).
3. **Adult present** for first powered skin test.
4. Stop if skin burns, pain, or irritation.
5. Say always: **student prototype, not a medical device**.
6. First tests on **yourself** (and teammate with consent), forearm first.

---

## 1) Buy list (India, Phase-1 mini)

### Must buy

| # | Item | Qty | Approx ₹ | Why |
|---|---|---:|---:|---|
| 1 | **ESP32 DevKit** (30-pin, USB) | 1 | 300–450 | Reads sensor, runs code |
| 2 | **AD8232 ECG module kit** (board + cable + pads if possible) | 1 | 550–800 | Amplifies tiny body signals |
| 3 | Extra **ECG electrode pads** pack | 1 | 150–300 | Pads dry out / fail |
| 4 | **Breadboard** 830 points | 1 | 70–120 | Easy wiring |
| 5 | **Jumper wires** M–M | 1 set | 40–80 | Connections |
| 6 | **USB data cable** for ESP32 (Micro-USB or Type-C — match board) | 1 | 50–100 | Upload + Serial Plotter |
| 7 | **Power bank** 5V | 1 | 0–400 | Safer skin-powered demo |
| 8 | Notebook + pen | 1 | 30–50 | Lab log (critical for contests) |

**Starter total:** about **₹1,200–2,200**

### Optional (after HELP works)

| Item | Approx ₹ | Why |
|---|---:|---|
| DFPlayer Mini + microSD + small speaker | 250–450 | Onboard “Help” voice |
| Neoprene/elastic strap + Velcro | 100–200 | Wearable look |
| ADS1115 ADC | 250–350 | Cleaner readings later |

### Software (free)

- Arduino IDE 2.x — https://www.arduino.cc/en/software  
- Python 3 (for optional TTS) — https://www.python.org  
- Driver if Windows doesn’t see ESP32 (CP210x or CH340 — depends on your board)

### Where to buy

- Amazon.in / Robu.in / Robodo / local robotics shop  
- Search: `ESP32 DevKit`, `AD8232 ECG module kit Arduino`

---

## 2) What each part does

```text
Muscle electricity (tiny)
        ↓
Electrode pads (pick up)
        ↓
AD8232 (make signal bigger)
        ↓
ESP32 (turn into numbers)
        ↓
USB → Computer Serial Plotter / Python
        ↓
If strong enough vs rest → "HELP" + speak
```

**AD8232 truth:** designed as **ECG/heart** front-end. You **repurpose** it for muscle-intent prototype. Say this to judges.

---

## 3) Tools / PC setup (Day 0 — before or while waiting for delivery)

### Install Arduino IDE
1. Install Arduino IDE 2.x  
2. **File → Preferences → Additional boards manager URLs** add:
   ```text
   https://espressif.github.io/arduino-esp32/package_esp32_index.json
   ```
3. **Boards Manager** → search **esp32** by Espressif → Install  
4. Connect ESP32 by USB  
5. **Tools → Board → ESP32 Dev Module**  
6. **Tools → Port** → pick the COM port (Windows) or `/dev/cu...` (Mac)  
7. Open **File → Examples → 01.Basics → Blink** → Upload  
8. If onboard LED blinks → board works  

### If upload fails
- Hold **BOOT** button on ESP32 while click Upload, release when “Connecting…”  
- Try another cable (**data** cable, not charge-only)  
- Install CP2102 or CH340 driver  

---

## 4) Wiring (AD8232 → ESP32)

### Pin map (most AD8232 boards)

| AD8232 pin | ESP32 pin | Wire color idea |
|---|---|---|
| **3.3V** or **VCC** | **3V3** | Red |
| **GND** | **GND** | Black |
| **OUTPUT** | **GPIO34** | Yellow |
| LO+ / LO− / SDN | leave unconnected for Phase-1 | — |

**Notes**
- Use **3.3V**, not 5V, unless your module clearly says 5V OK.  
- GPIO34 is **input-only analog** — perfect for sensor read.  
- Common GND is mandatory.

### Electrodes (typical 3-lead ECG cable)

Many kits use:

| Cable | Placement (Phase-1 FOREARM) |
|---|---|
| **Red** | Mid forearm muscle |
| **Yellow / white** | Along same muscle, ~3–5 cm away |
| **Green / black (REF)** | Bony area (elbow bone) |

**Exact colors vary by kit** — follow the sticker on **your** cable/board.

### Phase-1 placement (do this first)

**Forearm clench test (learning):**
1. Clean dry skin  
2. Stick 2 pads on muscle belly of inner forearm  
3. Stick reference on elbow bone  
4. Sit still → open Serial Plotter  
5. Clench fist hard 2 sec → relax  

You want: **rest lower / flatter**, **clench higher / busier**.

### Later (story placement — only after forearm works)

**Submental (under chin):** soft triangle under jaw, gently; reference on collarbone/bone area; adult supervision; don’t press hard on neck vessels.

---

## 5) Build order (do in this sequence)

| Step | Done when |
|---:|---|
| 1 | Parts ordered |
| 2 | Blink works on ESP32 |
| 3 | AD8232 wired; Serial numbers change when you touch leads |
| 4 | Forearm pads on; Plotter shows rest vs clench |
| 5 | Threshold set from your numbers |
| 6 | Serial prints `HELP` on action |
| 7 | Optional: Python speaks “Help” |
| 8 | Notebook has dates + trial counts |
| 9 | Film a 60–90 sec demo |

**Do not** skip to ML or 5 words before step 6.

---

## 6) Code files in this folder

| File | Purpose |
|---|---|
| `arduino/VocalBridge_Phase1_Plotter/VocalBridge_Phase1_Plotter.ino` | See live signal |
| `arduino/VocalBridge_Phase1_HELP/VocalBridge_Phase1_HELP.ino` | Detect HELP + print + optional marker for TTS |
| `python/help_tts_listener.py` | Speak “Help” when Serial says HELP |
| `docs/02_CALIBRATION_SHEET.md` | Fill-in numbers |
| `docs/03_LAB_NOTEBOOK_TEMPLATE.md` | Session log |
| `docs/04_VIDEO_SCRIPT.md` | If Top 200 |
| `wiring/WIRING.txt` | Quick pin map |

---

## 7) Calibration (10–15 minutes each session)

1. Upload **Plotter** sketch  
2. Open **Tools → Serial Plotter** (baud **115200**)  
3. Rest 10 seconds → write typical value range in notebook  
4. Action (clench or mouth HELP) 10 times → write peak/average range  
5. Choose threshold **T** between rest-high and action-low  
   - Example: rest ~400–600, action ~1200–2000 → try T = 900  
6. Upload **HELP** sketch, set `THRESHOLD` to T  
7. Test:
   - false HELP while idle → **raise T**  
   - miss real action → **lower T** or fix pads  
8. Recalibrate if person/placement/sweat changes  

**100 HELPs later** = better for multi-word ML. Phase-1 only needs a solid threshold first.

---

## 8) How HELP is decided (Phase-1)

```text
Read analog samples for ~150–250 ms window
→ compute average or mean absolute change
→ if value > THRESHOLD for DEBOUNCE time
→ print HELP once
→ cooldown 1–2 seconds (no spam)
```

This is **not** full English understanding.  
It is: **“this burst looks like the trained action we called HELP.”**

---

## 9) If Top 200 (video)

See `04_VIDEO_SCRIPT.md`.

Must show:
- problem in 15 sec  
- live demo  
- “not medical device”  
- both teammates if group  

---

## 10) Lab notebook (every session)

Date, goal, wiring photo, placement, threshold, trials, what failed, next step.

This is as important as code for IRIS / judges.

---

## 11) Troubleshooting

| Problem | Fix |
|---|---|
| No COM port | Driver + data cable + different USB port |
| Upload fail | Hold BOOT on upload; correct board |
| Flat line always | Check 3V3/GND/OUTPUT pin; loose jumper |
| Wild noise | Better pad stick, shorter wires, sit still, power bank |
| Only jumps when touching metal | Reference electrode not on skin properly |
| False HELP | Raise THRESHOLD, increase DEBOUNCE_MS |
| Never HELP | Lower THRESHOLD, stronger action, fresh pads |
| Values stuck 0 or 4095 | Wrong pin or supply |

---

## 12) Judge lines (memorize)

- “AD8232 is an ECG front-end; we repurpose it as a low-cost biopotential amplifier.”  
- “HELP is labeled pattern matching, not the chip knowing English.”  
- “Unsure → silence.”  
- “Phase-1 is rest vs Help; more words later.”  
- “Student prototype, not a medical device.”

---

## Bottom line

**Buy mini kit → Blink → wire AD8232 → Plotter → set threshold → HELP sketch → optional TTS → notebook → film.**

Everything else is Phase-2.
