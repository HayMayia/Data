# Calibration sheet (fill by hand)

Date: _______________  
Person tested: _______________  
Placement: forearm / under-chin / other: _______________  
ESP32 port: _______________  
Sketch: Plotter / HELP  

## Rest (idle) readings from Serial Plotter (smooth column)

| Trial | Approx value |
|---:|---:|
| 1 | |
| 2 | |
| 3 | |
| 4 | |
| 5 | |
| Typical rest range | ______ to ______ |

## Action (clench or mouth HELP) readings

| Trial | Approx peak / feature |
|---:|---:|
| 1 | |
| 2 | |
| 3 | |
| 4 | |
| 5 | |
| Typical action range | ______ to ______ |

## Chosen THRESHOLD

THRESHOLD = __________  

Reason: between rest-high (_____) and action-low (_____)

## Live test after setting THRESHOLD

| Test | Result (Y/N) | Notes |
|---|---|---|
| Idle 20 sec — any false HELP? | | |
| Action x10 — how many detected? | | |
| Swallow once — false HELP? | | |
| Weak action — detected? | | |

## Final settings for demo

THRESHOLD = ______  
DEBOUNCE_MS = ______  
COOLDOWN_MS = ______  
PRINT_DEBUG = true / false  

Photo of placement taken? Y/N  
Notebook page #: ______  
