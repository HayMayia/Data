# 14-day build plan (after parts arrive)

## Day 1 — PC setup
- Install Arduino IDE + ESP32 boards
- Blink upload OK
- Label bag of parts in notebook

## Day 2 — Wire without skin
- Wire AD8232 → ESP32 (3V3, GND, GPIO34)
- Upload Plotter sketch
- Touch/move leads — numbers should change

## Day 3 — Forearm first signal
- Place electrodes on forearm + bone reference
- Power bank preferred
- Serial Plotter: rest vs clench visible
- Fill calibration sheet rest/action ranges

## Day 4 — Threshold HELP
- Set THRESHOLD in HELP sketch
- Get HELP print on clench
- Tune false alarms

## Day 5 — Stability
- 20 rest + 20 action trials
- Record false HELP / missed HELP counts
- Fix pads / threshold

## Day 6 — Optional TTS
- pip install pyserial pyttsx3
- Run help_tts_listener.py on COM port
- Set PRINT_DEBUG false if needed

## Day 7 — Demo dry run
- Full table demo 10 times
- Teammate films practice
- Write 30-second pitch

## Day 8–9 — Under-chin attempt (optional)
- Only if forearm is solid
- Adult supervision
- Recalibrate threshold
- If bad signal, stay on forearm for contest demo and explain roadmap

## Day 10–11 — Reliability + notebook polish
- Clean wiring photos
- One-page results table
- Failure notes (swallow, motion)

## Day 12 — Video script
- Film 5 takes using docs/04_VIDEO_SCRIPT.md

## Day 13 — Q&A drill
- Both practice 10 viva questions
- Teammate explains his ops role

## Day 14 — Backup
- Second video take
- Spare pads packed
- Threshold written on paper taped near laptop

## Go / No-Go
- End of Day 3: no rest vs action difference → fix placement/wiring before anything else
- End of Day 5: cannot get HELP without constant false alarms → simplify demo to plotter + manual explanation + button backup only if needed
