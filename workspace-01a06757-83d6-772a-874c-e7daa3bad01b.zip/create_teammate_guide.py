#!/usr/bin/env python3
"""VocalBridge teammate guide PDF — beginner-friendly, not childish."""

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor, white, black
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, ListFlowable, ListItem, KeepTogether, HRFlowable
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pathlib import Path

OUT = Path("/home/user/VocalBridge_Teammate_Beginner_Guide.pdf")

NAVY = HexColor("#0B3D5C")
TEAL = HexColor("#1A7A6D")
LIGHT = HexColor("#F4F7FA")
SOFT = HexColor("#E8EEF2")
DARK = HexColor("#1A1A1A")
MUTED = HexColor("#4A5560")
ACCENT = HexColor("#C45C26")


def make_styles():
    base = getSampleStyleSheet()
    styles = {}
    styles["cover_title"] = ParagraphStyle(
        "cover_title", parent=base["Title"],
        fontName="Helvetica-Bold", fontSize=22, leading=26,
        textColor=NAVY, alignment=TA_CENTER, spaceAfter=8,
    )
    styles["cover_sub"] = ParagraphStyle(
        "cover_sub", parent=base["Normal"],
        fontName="Helvetica", fontSize=11, leading=14,
        textColor=MUTED, alignment=TA_CENTER, spaceAfter=4,
    )
    styles["h1"] = ParagraphStyle(
        "h1", parent=base["Heading1"],
        fontName="Helvetica-Bold", fontSize=14, leading=18,
        textColor=NAVY, spaceBefore=14, spaceAfter=8,
    )
    styles["h2"] = ParagraphStyle(
        "h2", parent=base["Heading2"],
        fontName="Helvetica-Bold", fontSize=11.5, leading=14,
        textColor=TEAL, spaceBefore=10, spaceAfter=5,
    )
    styles["body"] = ParagraphStyle(
        "body", parent=base["Normal"],
        fontName="Helvetica", fontSize=9.5, leading=13,
        textColor=DARK, alignment=TA_JUSTIFY, spaceAfter=6,
    )
    styles["bullet"] = ParagraphStyle(
        "bullet", parent=base["Normal"],
        fontName="Helvetica", fontSize=9.5, leading=12.5,
        textColor=DARK, leftIndent=8, spaceAfter=3,
    )
    styles["note"] = ParagraphStyle(
        "note", parent=base["Normal"],
        fontName="Helvetica-Oblique", fontSize=9, leading=12,
        textColor=MUTED, leftIndent=6, rightIndent=6, spaceAfter=8, spaceBefore=4,
    )
    styles["box"] = ParagraphStyle(
        "box", parent=base["Normal"],
        fontName="Helvetica", fontSize=9, leading=12,
        textColor=DARK, spaceAfter=3,
    )
    styles["box_title"] = ParagraphStyle(
        "box_title", parent=base["Normal"],
        fontName="Helvetica-Bold", fontSize=9.5, leading=12,
        textColor=NAVY, spaceAfter=4,
    )
    styles["small"] = ParagraphStyle(
        "small", parent=base["Normal"],
        fontName="Helvetica", fontSize=8, leading=10,
        textColor=MUTED, alignment=TA_CENTER,
    )
    styles["footer"] = ParagraphStyle(
        "footer", parent=base["Normal"],
        fontName="Helvetica", fontSize=8, leading=10,
        textColor=MUTED,
    )
    styles["qa_q"] = ParagraphStyle(
        "qa_q", parent=base["Normal"],
        fontName="Helvetica-Bold", fontSize=9.5, leading=12,
        textColor=NAVY, spaceBefore=6, spaceAfter=2,
    )
    styles["qa_a"] = ParagraphStyle(
        "qa_a", parent=base["Normal"],
        fontName="Helvetica", fontSize=9.5, leading=12.5,
        textColor=DARK, leftIndent=6, spaceAfter=4,
    )
    styles["mono"] = ParagraphStyle(
        "mono", parent=base["Normal"],
        fontName="Courier", fontSize=8.5, leading=11,
        textColor=DARK, leftIndent=10, spaceAfter=6,
    )
    return styles


def hr():
    return HRFlowable(width="100%", thickness=0.6, color=SOFT, spaceBefore=4, spaceAfter=8)


def info_box(title, lines, styles):
    data = [[Paragraph(title, styles["box_title"])]]
    for line in lines:
        data.append([Paragraph(line, styles["box"])])
    t = Table(data, colWidths=[16.5 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
        ("BOX", (0, 0), (-1, -1), 0.8, TEAL),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def warn_box(title, lines, styles):
    data = [[Paragraph(title, styles["box_title"])]]
    for line in lines:
        data.append([Paragraph(line, styles["box"])])
    t = Table(data, colWidths=[16.5 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), HexColor("#FFF5F0")),
        ("BOX", (0, 0), (-1, -1), 0.8, ACCENT),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def simple_table(headers, rows, col_widths, styles):
    head = [Paragraph(f"<b>{h}</b>", styles["box"]) for h in headers]
    data = [head]
    for row in rows:
        data.append([Paragraph(str(c), styles["box"]) for c in row])
    t = Table(data, colWidths=col_widths, repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), white),
        ("BACKGROUND", (0, 1), (-1, -1), white),
        ("BOX", (0, 0), (-1, -1), 0.5, NAVY),
        ("INNERGRID", (0, 0), (-1, -1), 0.3, SOFT),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            style_cmds.append(("BACKGROUND", (0, i), (-1, i), LIGHT))
    # fix header text color via Paragraph — already navy bg; recolor header paras
    t.setStyle(TableStyle(style_cmds))
    return t


def build():
    styles = make_styles()
    doc = SimpleDocTemplate(
        str(OUT),
        pagesize=A4,
        leftMargin=1.7 * cm,
        rightMargin=1.7 * cm,
        topMargin=1.4 * cm,
        bottomMargin=1.4 * cm,
        title="VocalBridge — Teammate Beginner Guide",
        author="VocalBridge Team",
    )
    story = []

    # ===== COVER =====
    story.append(Spacer(1, 1.2 * cm))
    story.append(Paragraph("VOCALBRIDGE", styles["cover_title"]))
    story.append(Paragraph(
        "A practical guide for teammates who are new to the project",
        styles["cover_sub"],
    ))
    story.append(Spacer(1, 0.3 * cm))
    story.append(hr())
    story.append(Paragraph(
        "Competition: <b>vivo Ignite 2026</b> &nbsp;|&nbsp; Category: <b>SoftTech</b><br/>"
        "Theme: <b>Advanced AI and Machine Learning Labs</b><br/>"
        "SDGs: <b>3 (Health)</b> and <b>10 (Reduced Inequalities)</b>",
        styles["cover_sub"],
    ))
    story.append(Spacer(1, 0.25 * cm))
    story.append(info_box(
        "How to use this guide",
        [
            "This is written for a beginner on the team — not for a child, and not for an expert.",
            "Read sections 1–6 first (what the project is and how it works).",
            "Read sections 7–10 before any demo, video, or judge questions.",
            "You do not need to build the full circuit alone. You do need to understand the story and your role.",
        ],
        styles,
    ))
    story.append(Spacer(1, 0.4 * cm))
    story.append(Paragraph(
        "Project title used in submission:<br/>"
        "<b>VocalBridge: Low-Cost Subvocal EMG Communication for Non-Verbal Individuals</b>",
        styles["body"],
    ))

    # ===== 1 =====
    story.append(Paragraph("1. What problem are we solving?", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "Some people cannot speak clearly or at all. Common reasons include conditions like ALS, "
        "stroke, or damage to the vocal cords. Even when they cannot produce a normal voice, many of them "
        "can still <b>try</b> to speak. When they try, muscles in the jaw, under the chin, and near the throat "
        "can still produce small electrical activity.",
        styles["body"],
    ))
    story.append(Paragraph(
        "Existing communication tools (like advanced eye-tracking devices) can cost on the order of "
        "<b>₹1.5 lakh or more</b>. That puts them out of reach for many families in India. Letter boards work, "
        "but they are slow in emergencies.",
        styles["body"],
    ))
    story.append(Paragraph(
        "<b>Our goal:</b> a low-cost prototype that detects a few emergency intents — especially "
        "<b>Help</b>, and later words like Yes, No, Water, Pain — and shows or speaks them so a caregiver can respond.",
        styles["body"],
    ))

    # ===== 2 =====
    story.append(Paragraph("2. What is VocalBridge in one paragraph?", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "VocalBridge is a student prototype of a wearable / sensor system. Surface electrodes pick up "
        "tiny muscle signals when the user attempts a word. Electronics amplify those signals. A microcontroller "
        "(ESP32) turns them into numbers. Software cleans noise and compares the pattern with examples we recorded "
        "earlier. If the pattern matches <b>HELP</b> with enough confidence, the system shows <b>HELP</b> on screen "
        "and can play it through a speaker or phone text-to-speech.",
        styles["body"],
    ))
    story.append(info_box(
        "Important honesty (say this to judges)",
        [
            "• This is a student prototype, not a certified hospital device.",
            "• It needs residual muscle activity. If those muscles are completely inactive, this method may not work.",
            "• Version 1 uses a small vocabulary. It is not full free conversation.",
            "• Wrong guesses are dangerous, so if the system is unsure, it should stay silent.",
        ],
        styles,
    ))

    # ===== 3 =====
    story.append(Paragraph("3. Key words you should know", styles["h1"]))
    story.append(hr())
    story.append(simple_table(
        ["Term", "Meaning in this project"],
        [
            ["EMG", "Electromyography: measuring electrical activity from muscles through the skin."],
            ["Surface electrodes", "Sticky pads on the skin (not needles) that pick up signals."],
            ["Subvocal / attempted speech", "Trying to say a word with little or no audible sound; muscles may still activate."],
            ["AD8232", "A low-cost chip module made for ECG (heart signals). We repurpose it as a cheap amplifier for body signals."],
            ["ESP32", "A small programmable board that reads sensor values and can talk to a computer over USB or Bluetooth."],
            ["Signal", "The changing numbers coming from the sensor over time (looks like a wave on screen)."],
            ["Noise", "Unwanted interference: movement, swallowing, loose pads, electrical hum from power lines."],
            ["Threshold", "A cutoff value: above it we treat the attempt as “active” (e.g. HELP); below it as rest."],
            ["Calibration", "Adjusting the system to a person/session using recorded examples — not one magic permanent setting."],
            ["Classification", "Choosing which label (HELP / REST / YES…) best matches a new signal pattern."],
            ["Confidence", "How sure the system is. Low confidence → stay silent."],
            ["TTS / speaker", "Text-to-speech or a small speaker that says the word out loud."],
            ["Phase-1", "First working demo: usually REST vs HELP only. Not the full 5-word dream yet."],
            ["AAC", "Augmentative and Alternative Communication — tools that help people communicate without normal speech."],
        ],
        [3.2 * cm, 13.3 * cm],
        styles,
    ))

    # ===== 4 =====
    story.append(Paragraph("4. How the system works (pipeline)", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "Think of the project as a chain. If one link fails, the demo fails.",
        styles["body"],
    ))
    story.append(Paragraph(
        "1) <b>Muscles activate</b> when the user tries a word.<br/>"
        "2) <b>Electrodes</b> pick up tiny voltages on the skin.<br/>"
        "3) <b>AD8232 module</b> amplifies those voltages.<br/>"
        "4) <b>ESP32</b> samples the amplified signal many times per second.<br/>"
        "5) <b>Software</b> filters noise and measures features (strength, timing, shape).<br/>"
        "6) <b>Decision rule or model</b> compares the new pattern with labeled training examples.<br/>"
        "7) If confident: <b>screen + speaker</b> output the word (e.g. Help).",
        styles["body"],
    ))
    story.append(Paragraph(
        "<b>ASCII overview</b>",
        styles["h2"],
    ))
    story.append(Paragraph(
        "Skin electrodes → AD8232 (amplify) → ESP32 (read numbers)<br/>"
        "→ USB/computer software (clean + compare) → “HELP” on screen / speaker",
        styles["mono"],
    ))

    # ===== 5 =====
    story.append(Paragraph("5. How it “knows” the word HELP (critical)", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "The device does <b>not</b> understand English. It does not hear the word “help” like a microphone does "
        "in normal speech recognition. It also does not read thoughts.",
        styles["body"],
    ))
    story.append(Paragraph(
        "What it does:",
        styles["body"],
    ))
    story.append(Paragraph(
        "• During <b>training</b>, we record many muscle-signal examples while the user attempts HELP, and we <b>label</b> them HELP.<br/>"
        "• We also record REST (no attempt) and label those REST.<br/>"
        "• Each attempt becomes a simple “fingerprint” (for example how strong and how long the burst is).<br/>"
        "• Later, a new attempt is compared to those groups. If it is closest to the HELP group and confident enough, we output HELP.",
        styles["body"],
    ))
    story.append(Paragraph(
        "Two HELP attempts are never identical. That is normal. We train on many examples so small natural differences "
        "still fall inside the HELP region. If an attempt is too weak or too different, the system should stay silent "
        "instead of guessing randomly.",
        styles["body"],
    ))
    story.append(warn_box(
        "Beginner misconception to avoid",
        [
            "Wrong: “Any chin movement means HELP.”",
            "Right: “A pattern similar to our labeled HELP examples means HELP; uncertain patterns stay silent.”",
            "Wrong: “We hardcoded the English word into the sensor.”",
            "Right: “We taught labels to patterns. The sensor only measures; software decides.”",
        ],
        styles,
    ))

    # ===== 6 =====
    story.append(Paragraph("6. About the AD8232 sensor (be honest)", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "The AD8232 is an Analog Devices front-end designed mainly for <b>ECG / heart-rate</b> style signals. "
        "It is not a hospital EMG instrument. In this project we <b>repurpose</b> it as a low-cost amplifier for "
        "surface biopotential activity so we can prototype muscle-intent detection on a student budget.",
        styles["body"],
    ))
    story.append(Paragraph(
        "That means: it can be good enough to show rest vs a clear muscle attempt, but it has limits. Heartbeat noise, "
        "motion, and placement quality all matter. If judges ask “Isn’t this for heartbeat?”, answer yes — and explain "
        "we are using it as a cheap biopotential amplifier for a scoped prototype.",
        styles["body"],
    ))

    # ===== 7 =====
    story.append(Paragraph("7. What we are building first (Phase-1)", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "We do not need the full five-word neckband product for the first working demo. Phase-1 success looks like this:",
        styles["body"],
    ))
    story.append(Paragraph(
        "1. Electrodes on the body (start on the <b>forearm</b> to learn; throat/chin later if ready).<br/>"
        "2. A live graph on the computer shows a clear difference between rest and action.<br/>"
        "3. When the user performs the agreed action (clench or clearly mouthed HELP), the system prints or speaks <b>HELP</b>.<br/>"
        "4. At rest, it should not spam false HELPs.<br/>"
        "5. We can explain safety and limits.",
        styles["body"],
    ))
    story.append(Paragraph(
        "Later phases (only if Phase-1 works): more words, better filtering, optional multi-channel setup, cleaner wearable strap, onboard speaker module.",
        styles["body"],
    ))

    # ===== 8 =====
    story.append(Paragraph("8. Parts and rough cost (starter)", styles["h1"]))
    story.append(hr())
    story.append(simple_table(
        ["Item", "Role", "Rough ₹"],
        [
            ["ESP32 board", "Reads signal, runs logic", "300–400"],
            ["AD8232 module", "Amplifies tiny skin signals", "300–700 (kit)"],
            ["Electrode pads + cable", "Skin contact", "often in kit / 150–300"],
            ["Breadboard + jumpers", "Temporary wiring", "100–200"],
            ["USB cable", "Program + view graph", "50–100"],
            ["Power bank", "Safer power during skin tests", "0–400"],
            ["Phone/laptop speaker (TTS)", "Says “Help”", "0"],
            ["Notebook", "Lab log", "30–50"],
        ],
        [4.5 * cm, 8.5 * cm, 3.5 * cm],
        styles,
    ))
    story.append(Paragraph(
        "Phase-1 total is often around <b>₹1,200–2,000</b> depending on what you already own. "
        "Optional later: DFPlayer + small speaker (~₹300–450) for onboard audio.",
        styles["note"],
    ))

    # ===== 9 =====
    story.append(Paragraph("9. Safety rules (non-negotiable)", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "• Use <b>surface electrodes only</b> (sticky pads). No needles.<br/>"
        "• Prefer <b>battery / power-bank</b> power when electrodes are on skin.<br/>"
        "• Adult present for first powered tests.<br/>"
        "• Stop if skin irritation occurs.<br/>"
        "• Never claim this is a certified medical device or a guaranteed clinical solution.<br/>"
        "• Demo on team members first; any other volunteer needs clear consent and supervision.",
        styles["body"],
    ))

    # ===== 10 =====
    story.append(Paragraph("10. Team roles", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "A group entry means both names can face questions. Zero contribution is a risk.",
        styles["body"],
    ))
    story.append(simple_table(
        ["Role", "Main responsibilities"],
        [
            ["Technical lead", "Wiring, code, signal graph, threshold/model, making HELP trigger reliably, explaining the method."],
            ["Operations lead (beginner-friendly)", "Lab notebook, trial counts, photos, filming, problem/impact script, demo logistics, BOM checklist, SDG lines in your own words."],
            ["Shared", "Both must know the problem, Phase-1 demo story, safety, and limits. Both practice Q&A."],
        ],
        [4.0 * cm, 12.5 * cm],
        styles,
    ))
    story.append(Paragraph(
        "If you are the beginner teammate: you are not useless. You own process quality and communication. "
        "If you skip that work, the team becomes a one-person project with two names — judges notice.",
        styles["note"],
    ))

    # ===== 11 =====
    story.append(Paragraph("11. What the beginner teammate does in practice", styles["h1"]))
    story.append(hr())
    story.append(Paragraph("<b>Lab notebook (every work session)</b>", styles["h2"]))
    story.append(Paragraph(
        "Write date, who was present, goal for the session, what you tried, what happened, what failed, next step. "
        "Add rough numbers if you have them (for example: rest average, action average, threshold used).",
        styles["body"],
    ))
    story.append(Paragraph("<b>Trial counts</b>", styles["h2"]))
    story.append(Paragraph(
        "Example: “HELP attempts: 20. REST windows: 20. False triggers: 2. Missed HELPs: 3.” "
        "This is real experimental work.",
        styles["body"],
    ))
    story.append(Paragraph("<b>Photos / evidence</b>", styles["h2"]))
    story.append(Paragraph(
        "Wiring photo, electrode placement photo, Serial Plotter screenshot, demo setup. These prove the project is real.",
        styles["body"],
    ))
    story.append(Paragraph("<b>Video (only if shortlisted later)</b>", styles["h2"]))
    story.append(Paragraph(
        "One team video of the working model. You can film and speak the problem/impact section while the technical lead runs the demo. "
        "Stage 1 idea submission did not require this video.",
        styles["body"],
    ))
    story.append(Paragraph("<b>Demo stage management</b>", styles["h2"]))
    story.append(Paragraph(
        "Before a presentation: checklist (power bank charged, pads ready, code loaded, quiet background). "
        "During demo: hold camera/laptop angle, start recording, show the screen clearly.",
        styles["body"],
    ))

    # ===== 12 =====
    story.append(Paragraph("12. Calibration in plain language", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "Calibration is not a single perfect setting forever. For Phase-1 it usually means:",
        styles["body"],
    ))
    story.append(Paragraph(
        "1. Confirm rest and action look different on the graph.<br/>"
        "2. Measure typical rest values and typical HELP/action values.<br/>"
        "3. Choose a threshold between them.<br/>"
        "4. If the system false-triggers at rest, raise the threshold.<br/>"
        "5. If real HELPs are missed, lower it carefully or fix electrode contact.<br/>"
        "6. Recheck when the person, pad position, or session changes.",
        styles["body"],
    ))
    story.append(Paragraph(
        "Later, multi-word systems use many labeled examples per word and a model with a confidence gate. "
        "That is still “teaching by examples,” not magic.",
        styles["body"],
    ))

    # ===== 13 =====
    story.append(Paragraph("13. Competition context (vivo Ignite)", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "• <b>Stage 1:</b> idea + form fields + poster/file (already submitted as a group if you registered that way).<br/>"
        "• <b>Later stages (if shortlisted):</b> working-model video and further evaluation rounds; finale is in-person for top teams.<br/>"
        "• <b>Group size:</b> 2–3 members for group entries. If a member leaves, ask official support how to update the team or continue.<br/>"
        "• <b>Group video (if required later):</b> one project video for the team. Both members do not each submit separate idea videos. "
        "It is wise for both members to appear and speak at least briefly.",
        styles["body"],
    ))
    story.append(Paragraph(
        "Our form choices used for this project concept: SoftTech Innovations; Advanced AI and Machine Learning Labs; SDG 3 and 10.",
        styles["note"],
    ))

    # ===== 14 =====
    story.append(Paragraph("14. Judge / viva questions (learn these)", styles["h1"]))
    story.append(hr())

    qa = [
        ("What is your project?",
         "A low-cost prototype that uses surface muscle signals when someone attempts speech-related movement, and turns a small set of emergency intents like HELP into text and speech."),
        ("Who is it for?",
         "People who cannot speak well but still have some residual muscle activity when they try. Not for people with zero remaining speech-muscle signal."),
        ("How does it detect HELP?",
         "We record labeled examples, convert signals into simple patterns, and match new attempts to those examples. It does not understand English by itself."),
        ("Is the sensor an EMG medical device?",
         "We use a low-cost AD8232-based module, which is designed as an ECG/heart front-end, repurposed as a student biopotential amplifier. Prototype only."),
        ("Why not just use a microphone?",
         "The target users may not produce usable audible speech. We are targeting attempted muscle activity, not normal voice input."),
        ("What is Phase-1 success?",
         "Reliable rest vs HELP style detection with a visible signal and safe output, plus clear limits documented."),
        ("What can go wrong?",
         "Loose electrodes, motion, swallowing, electrical noise, weak attempts, and over-claiming medical accuracy."),
        ("What did you personally do on the team?",
         "Answer with your real role: notebook, trials, filming, demo support, or technical build — be specific."),
        ("How much does it cost?",
         "Starter prototype on the order of a few thousand rupees in parts, much cheaper than many commercial AAC devices."),
        ("Is this safe?",
         "Surface electrodes, battery/power-bank preference, adult supervision for first tests, no medical certification claims."),
    ]
    for q, a in qa:
        story.append(Paragraph(f"Q: {q}", styles["qa_q"]))
        story.append(Paragraph(f"A: {a}", styles["qa_a"]))

    # ===== 15 =====
    story.append(Paragraph("15. 30-second team pitch (memorize)", styles["h1"]))
    story.append(hr())
    story.append(info_box(
        "Speak roughly like this",
        [
            "“Many people lose speech after neurological injury or disease, and good communication devices can cost over a lakh rupees. "
            "VocalBridge is our low-cost prototype that reads residual muscle activity when a person attempts a word. "
            "We amplify the skin signal, process it, and if the pattern matches HELP with enough confidence, the system displays and speaks Help. "
            "It is a student prototype with a small vocabulary and clear safety limits, aligned with better health access and reduced inequality.”",
        ],
        styles,
    ))

    # ===== 16 =====
    story.append(Paragraph("16. Suggested demo script (later video / live)", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "1. Beginner teammate: problem + who it helps (15–20 seconds).<br/>"
        "2. Technical lead: show live graph, perform HELP attempt, trigger output (20–30 seconds).<br/>"
        "3. Either: cost + “not a medical device” + next steps (15 seconds).<br/>"
        "4. Both: names, grade, school, project title.",
        styles["body"],
    ))

    # ===== 17 =====
    story.append(Paragraph("17. What success looks like vs what can wait", styles["h1"]))
    story.append(hr())
    story.append(simple_table(
        ["Needed for a serious prototype path", "Can wait"],
        [
            ["Clear rest vs action signal", "Perfect 5-word accuracy"],
            ["HELP output with few false alarms", "Beautiful commercial neckband shell"],
            ["Safety explanation", "Clinical hospital trials"],
            ["Notebook + photos of real work", "On-device advanced neural nets"],
            ["Honest limits", "Solving every type of muteness"],
        ],
        [8.2 * cm, 8.3 * cm],
        styles,
    ))

    # ===== 18 =====
    story.append(Paragraph("18. If you only remember 8 lines", styles["h1"]))
    story.append(hr())
    story.append(Paragraph(
        "1. Problem: speech loss + expensive communication devices.<br/>"
        "2. Idea: detect residual muscle patterns for emergency words.<br/>"
        "3. Method: electrodes → amplify → ESP32 → software match → screen/speaker.<br/>"
        "4. HELP is learned from examples, not magic English understanding.<br/>"
        "5. AD8232 is an ECG-style module repurposed for a student prototype.<br/>"
        "6. Phase-1 is rest vs HELP first.<br/>"
        "7. Unsure → silence. Safety + honesty matter.<br/>"
        "8. Every teammate must have a real role and basic viva answers.",
        styles["body"],
    ))

    story.append(Spacer(1, 0.5 * cm))
    story.append(hr())
    story.append(Paragraph(
        "VocalBridge — Teammate Beginner Guide &nbsp;|&nbsp; vivo Ignite 2026 &nbsp;|&nbsp; "
        "Read once fully, then re-read sections 5, 10, 14, and 15 before any demo.",
        styles["small"],
    ))
    story.append(Paragraph(
        "This document is for internal team learning. Follow official vivo Ignite rules on the portal for all submissions.",
        styles["small"],
    ))

    def add_page_number(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(MUTED)
        page = canvas.getPageNumber()
        canvas.drawCentredString(A4[0] / 2, 1.0 * cm, f"VocalBridge teammate guide  ·  page {page}")
        canvas.setStrokeColor(NAVY)
        canvas.setLineWidth(1.5)
        canvas.line(1.7 * cm, A4[1] - 0.9 * cm, A4[0] - 1.7 * cm, A4[1] - 0.9 * cm)
        canvas.restoreState()

    doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
    print(f"Wrote {OUT} ({OUT.stat().st_size} bytes)")


if __name__ == "__main__":
    build()
