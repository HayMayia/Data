# VocalBridge — Parts List, Costs, Functions & Calibration
### Honest Grade-8 build guide (India prices, approx. mid‑2026 retail)

**Currency:** Indian Rupees (₹)  
**Prices:** approximate online (Robu.in / Amazon.in / local electronics). Expect ±20–30% variation.  
**Rule:** Start with **Option A**. Upgrade only if Week‑1 signal is usable.

---

# 0) Can you make it? (honest answer first)

| Version | Can a Grade‑8 team of 2 finish? | Time | Confidence |
|---|---|---|---|
| **Phase‑1:** 1 muscle channel → screen says HELP | **Yes**, if you work steadily | ~2–4 weeks after parts arrive | **Medium–High** |
| **Phase‑2:** 2–3 channels, Yes/No/Help | Possible | ~4–8 weeks | **Medium** |
| **Full abstract:** 5 words + BLE neckband + solid ML | Hard | **2–3+ months** | **Low in “few weeks”** |

**Bottom line:**  
You **can** make a real, impressive **Phase‑1**.  
You **should not** bet the video on perfect 5‑word accuracy in a few weeks.  
Submit the full idea → build Phase‑1 first → expand if signal is good.

**You can make it IF:**
1. Parts ordered this week  
2. One person owns hardware+code every day  
3. Success = HELP works / clear signal graph (not 5 perfect words)  
4. Lab notebook + safety (battery only on skin)

**You will struggle IF:**
- You wait for perfect understanding before ordering  
- You aim for full AlterEgo‑level demo immediately  
- Nobody touches the hardware for 10 days  

---

# 1) OPTION A — Starter kit (recommended first buy)

**Target total: ~₹2,050 – ₹2,400**

| # | Item | Qty | Approx. ₹ | Where | Function (what it does) | Calibration / setup |
|---|---|---:|---:|---|---|---|
| 1 | **ESP32 DevKit** (30‑pin, WiFi+BLE) | 1 | 300–400 | Robu / Amazon | Brain of the project: reads sensor voltage, can send data by USB or Bluetooth, runs your program | Install **Arduino IDE** + ESP32 board package. Select correct board/port. Upload “Blink” first to prove PC↔board works. |
| 2 | **AD8232 ECG sensor module** (single‑lead) | 1 first *(then +2 later)* | 250–350 each | Robu / Amazon | Amplifies tiny body electrical signals so ESP32 can read them. We repurpose heart module for **muscle** signals | See **§4 AD8232 setup**. Verify output moves when you tense a muscle before any ML. |
| 3 | **Disposable ECG/EMG electrodes** (pack of 20–50) | 1 pack | 150–300 | Amazon / medical store | Sticky pads that contact skin and pick up muscle electricity | Stick on clean dry skin. Replace when dry/loose. Do **impedance check**: poor stick = noisy signal. |
| 4 | **Electrode snap wires / cable** for AD8232 | 1 set | often included / 50–100 | with module | Connects electrode pads to AD8232 | Match RA/LA/RL (or + / − / GND) labels; don’t swap ground. |
| 5 | **Breadboard** (830 points) | 1 | 70–100 | Robu | Temporary wiring without soldering | Seat module & ESP32 legs fully; use short jumpers. |
| 6 | **Jumper wires** M‑M (40 pcs) | 1 set | 40–80 | Robu | Connect 3V3, GND, OUTPUT between AD8232 ↔ ESP32 | Color‑code: red=3V3, black=GND, yellow=signal. |
| 7 | **Micro‑USB / USB‑C cable** (data capable) | 1 | 50–100 | local | Power ESP32 + upload code + serial plotter | Use a **data** cable (not charge‑only). |
| 8 | **Power bank** (5V) **or** **LiPo 3.7V + TP4056** | 1 | 200–400 | Amazon / Robu | Safe power when electrodes are on skin (prefer isolated from wall mains) | **Never** rely on risky mains setups with skin electrodes. Power bank USB to ESP32 is the simple safe demo path. |
| 9 | **Elastic / cloth strap + Velcro** | 1 | 50–150 | local / Amazon | Holds sensor/wires for demo (arm first, neck later) | Adjust snug not painful; mark electrode positions with pen for repeatability. |
| 10 | **Notebook + pen** | 1 | 30–50 | local | Lab log: date, placement, what worked | Every session: photo + 5 lines written. This is part of the project. |

### Option A minimum buy order (Phase‑1, lowest risk)
If money/time tight, buy **only this first**:

1. ESP32 (~₹350)  
2. **1×** AD8232 (~₹300)  
3. Electrode pack (~₹250)  
4. Breadboard + jumpers + USB cable (~₹200)  
5. Power bank you may already have (₹0)  

**Phase‑1 mini total: ~₹1,100 – ₹1,400**  
(Add 2 more AD8232 only after 1 channel works.)

---

# 2) OPTION B — Better quality (after Phase‑1 works)

**Extra ~₹800 – ₹1,500**

| Item | Approx. ₹ | Function | When to buy |
|---|---:|---|---|
| **2 more AD8232** (total 3) | 500–700 | Multi‑channel throat array like abstract | Only if 1 channel is clean |
| **ADS1115** 16‑bit ADC module | 250–350 | Cleaner digital reading than ESP32’s built‑in ADC | If signal looks stair‑steppy / noisy |
| **Reusable Ag/AgCl electrodes** | 400–700 | Better repeat sessions, less waste | If disposable pads fail often |
| **Electrode gel** | 100–200 | Better skin contact | Dry skin / weak signal |
| **Neoprene neck strap** | 150–250 | Looks more “product” in video | For final demo cosmetics |
| **OLED 0.96" display** (optional) | 150–250 | Show HELP on device without laptop | Nice for video |

---

# 3) Software (all free)

| Software | Function | “Calibration” |
|---|---|---|
| **Arduino IDE** | Program ESP32 | Board = ESP32 Dev Module; upload speed 115200 |
| **Serial Plotter** (in Arduino IDE) | See live muscle wave | Y‑axis stable at rest; spikes when you clench/mouth word |
| **Python 3** + NumPy, SciPy, Matplotlib | Filter + graphs + ML later | Install once; test `import numpy` |
| **scikit‑learn** (first ML) | Easy classifier (Random Forest) | Train/test split; print accuracy |
| **TensorFlow/Keras** (optional later) | 1D‑CNN | Only after RF baseline works |
| **Phone TTS** or laptop screen | Speak/show word | Test “HELP” audio once offline |

**Laptop/PC required** for Phase‑1 (even a school lab PC). Phone‑only full stack is harder.

---

# 4) What each electronic part does (simple)

```
SKIN MUSCLE  →  ELECTRODES  →  AD8232 (amplify)  →  ESP32 (measure)  →  USB/BLE  →  COMPUTER
   tiny µV          stickers         bigger signal         numbers 0–4095      plot / AI / "HELP"
```

| Part | Kid-level function |
|---|---|
| Electrodes | “Fingers” listening to muscle electricity |
| AD8232 | Megaphone for tiny signals |
| ESP32 | Reads megaphone voltage many times per second |
| Code | Decides “is this HELP or rest?” |
| Screen/TTS | Shows or speaks the word |
| Power bank | Safe battery power |

---

# 5) Wiring (Phase‑1 — one AD8232 + ESP32)

**Safety first**
- Electrodes on skin → power ESP32 from **power bank** or battery path you understand  
- Adult present for first powered skin test  
- Surface electrodes only (no needles)  
- Stop if skin irritation  

**Typical AD8232 → ESP32 connections** (check your module’s pin labels):

| AD8232 pin | ESP32 pin | Notes |
|---|---|---|
| 3.3V / VCC | 3V3 | Do **not** use 5V if module is 3.3V |
| GND | GND | Common ground mandatory |
| OUTPUT | GPIO34 (or 35/32/33 analog) | Analog input only pins on ESP32 |
| SDN / LO+ / LO− | often unused at start | Optional leads‑off detect later |

**Electrodes (common ECG cable colors — verify your board):**
- **Red** → one side of muscle  
- **Yellow** → other side of muscle (differential pair)  
- **Green/Black** → ground / reference on bony area (elbow bone / collarbone area — **not** random wet metal)

**Phase‑1 placement (EASIER than throat — do this first):**
- Put pair on **forearm** muscle  
- Clench fist hard = big signal  
- Learn the system before neck

**Phase‑1.5 placement (closer to VocalBridge story):**
- Under chin soft area (submental) while silently mouthing “help”  
- Reference on bony area  
- Adult supervision; gentle pressure only  

---

# 6) Calibration — what it means (3 layers)

People say “calibrate” for three different things. You need all three over time.

---

## 6.1 Hardware / signal calibration (Day 1–3) — **mandatory**

**Goal:** Rest looks quiet; action looks different.

### Steps
1. Upload ESP32 code that does `analogRead` + `Serial.println` at ~100–200 samples/sec.  
2. Open **Serial Plotter**.  
3. Sit still, arms relaxed → line should be relatively flat (some noise OK).  
4. Clench fist 2 seconds → clear rise/change.  
5. Relax → returns toward baseline.  

### Pass test
- You can **see** clench vs rest without guessing  
- Repeat 10 times; pattern similar  

### Fail test → fix before any AI
| Problem | Likely cause | Fix |
|---|---|---|
| Flat forever | Wrong pin / no power / cable | Recheck 3V3, GND, OUTPUT pin |
| Wild noise | Bad contact / mains / moving wires | Better stick, shorter wires, power bank, sit still |
| Rails to max | Wrong voltage / wiring | Check 3.3V vs 5V; pinout |
| Only moves when you touch metal | Grounding issue | Reference electrode on skin bone landmark |

### Simple software “zeroing”
```text
Record 2 seconds of REST average = baseline
Signal for decisions = abs(current - baseline)
Or use envelope after filtering
```
Recalculate baseline at the **start of every session**.

---

## 6.2 Threshold calibration (Phase‑1 HELP detector) — **no ML yet**

**Goal:** One number that means “user intended HELP.”

### Steps
1. Collect 20 rest windows (0.5–1.0 s each).  
2. Collect 20 clench or silent‑“help” windows.  
3. Compute a simple feature: **mean absolute value** or **max** of signal in window.  
4. Plot or write the numbers in notebook.  
5. Choose threshold **T** between rest cluster and action cluster.  
   - Example: rest MAV ≈ 20–40, action ≈ 100–200 → try T = 70  
6. Live test: only speak/show HELP when feature > T for 200–300 ms (debounce).  

### Recalibrate when
- Different person  
- Different electrode position  
- Different time of day / sweaty skin  
- New electrode brand  

**Time needed:** 10–15 minutes at start of each demo day.

---

## 6.3 ML calibration / personalization (Phase‑2) — **after threshold works**

**Goal:** Distinguish 2–5 words for **your** muscles.

### Data collection protocol
For each word (start with **HELP** and **REST**, then **YES/NO**):

| Word | Repetitions | How |
|---|---:|---|
| REST | 30 | Sit silent, normal breathing |
| HELP | 30 | Silently mouth “help” the same way each time |
| YES | 30 | only after 2‑class works |
| NO | 30 | … |
| WATER / PAIN | 30 | last |

**Rules**
- Same electrode positions (mark skin with washable pen)  
- 1 second action + 1 second rest between reps  
- Delete swallows / laughs / head turns (artifact)  
- Save files: `help_01.csv`, `rest_01.csv`…

### Train simple model first
1. Features per window: MAV, RMS, zero‑crossings, maybe FFT peak  
2. RandomForest or Logistic Regression  
3. Hold out 20% test data  
4. Report **accuracy + confusion matrix** honestly  

### “2‑minute calibration” for a new user (what abstract means)
1. New user wears electrodes  
2. Guided app: “Mouth HELP” ×10, “YES” ×10…  
3. Fine‑tune or retrain last layer / small model on their data  
4. Set confidence threshold so unsure → silence  

**You do not need this working for idea submission.**  
You need to **explain** it; build it after Phase‑1.

---

## 6.4 Optional: AD8232 / ADC calibration

| Check | How | Why |
|---|---|---|
| ADC raw range | Print min/max at rest and action | Know usable span |
| 50 Hz hum | See Serial Plotter wiggle at power frequency | Add notch filter in code later |
| Sampling rate | timestamp N samples | Aim ~100–250 Hz for muscles |

You do **not** need lab-grade voltage calibration for the competition if your **relative** patterns separate classes.

---

# 7) Shopping checklist (print this)

### Order this week (Phase‑1)
- [ ] ESP32 DevKit  
- [ ] AD8232 ×1  
- [ ] Electrode pack  
- [ ] Breadboard + jumpers  
- [ ] USB data cable  
- [ ] Power bank  
- [ ] Strap / tape  
- [ ] Notebook  

### Order only if Phase‑1 passes
- [ ] AD8232 ×2 more  
- [ ] ADS1115 (optional)  
- [ ] Better electrodes / gel  
- [ ] Neoprene strap / OLED  

### Total money to commit now
**₹1,200 – ₹2,400** depending on mini vs full Option A.

---

# 8) 14‑day calibration & build calendar

| Day | Goal | Calibration focus |
|---:|---|---|
| 1 | Order parts; install Arduino IDE | PC toolchain works |
| 2–3 | Parts arrive; Blink on ESP32 | Board alive |
| 4 | Wire AD8232; Serial Plotter | Rest vs clench visible |
| 5 | Baseline zeroing + threshold T | HELP detector offline numbers |
| 6 | Live HELP on screen | Debounce false triggers |
| 7 | **GO/NO‑GO** | If no visible signal → fix placement or ask mentor; consider TalkBox backup |
| 8–10 | 40–60 labeled trials; notebook | Data quality |
| 11–12 | Optional 2nd class YES or silent‑mouth vs clench | Threshold or tiny ML |
| 13 | Film video (5 takes) | Recalibrate T before filming |
| 14 | Backup video + Q&A practice | Explain calibration in your words |

---

# 9) How you’ll explain calibration to judges (memorize)

> “Calibration for us means three things.  
> First, we check the raw signal: rest is low, action is high.  
> Second, we set a threshold from our own recorded numbers so HELP triggers only when we intend it.  
> Third, for more words, we record many examples from the same person and train a small model, then retest on new examples we held back.  
> If the model is unsure, it stays silent.”

---

# 10) Final honesty meter

| Statement | Truth |
|---|---|
| “I can submit this idea.” | **Yes** |
| “I can buy these parts.” | **Yes**, ~₹1–2.5k |
| “I can make Phase‑1 HELP demo.” | **Yes, if you start now and simplify** |
| “I will definitely finish 5‑word neck AI in a few weeks.” | **No guarantee — plan as Phase‑2** |
| “Calibration is magic once.” | **No — redo each session/person** |

**If you’re still unsure:**  
Don’t decide based on fear of the full abstract.  
Decide based on this smaller promise:

> “In two weeks after parts arrive, can we show a muscle signal and print HELP?”  
> If yes → you can make *a* VocalBridge.  
> Full 5‑word product is the mountain behind the first hill.

---

## Quick cost summary

| Kit | Approx. total | What you can demo |
|---|---:|---|
| **Mini Phase‑1** | ₹1,100–1,400 | HELP from 1 channel |
| **Option A** | ₹2,050–2,400 | Path to 3 channels |
| **Option B upgrades** | +₹800–1,500 | Better signal / look |

**Software:** ₹0  
**Most important free item:** your lab notebook + consistent electrode marks.
