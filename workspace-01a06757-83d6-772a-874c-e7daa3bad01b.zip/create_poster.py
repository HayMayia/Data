#!/usr/bin/env python3
"""Generate VocalBridge vivo Ignite 2026 digital poster (landscape 11x8.5 in)."""

from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.units import inch
from reportlab.lib.colors import Color, white, black, HexColor
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from pathlib import Path
import math

# Page: landscape letter = 11 x 8.5 inches (close to 8x11 landscape guideline)
PAGE_W, PAGE_H = landscape(letter)  # 792 x 612 points

# Palette (max ~3 colors + neutrals)
NAVY = HexColor("#0B3D5C")
TEAL = HexColor("#1A7A6D")
ACCENT = HexColor("#E8A317")
LIGHT = HexColor("#F4F7FA")
SOFT = HexColor("#E6EEF3")
DARK = HexColor("#1A1A1A")
MUTED = HexColor("#4A5560")
WHITE = white

OUT_PDF = Path("/home/user/VocalBridge_Digital_Poster.pdf")
OUT_PNG = Path("/home/user/VocalBridge_Digital_Poster.png")


def draw_rounded_rect(c, x, y, w, h, r, fill=None, stroke=None, sw=0.5):
    c.saveState()
    if fill:
        c.setFillColor(fill)
    if stroke:
        c.setStrokeColor(stroke)
        c.setLineWidth(sw)
    p = c.beginPath()
    p.moveTo(x + r, y)
    p.lineTo(x + w - r, y)
    p.arcTo(x + w - 2 * r, y, x + w, y + 2 * r, -90, 90)
    p.lineTo(x + w, y + h - r)
    p.arcTo(x + w - 2 * r, y + h - 2 * r, x + w, y + h, 0, 90)
    p.lineTo(x + r, y + h)
    p.arcTo(x, y + h - 2 * r, x + 2 * r, y + h, 90, 90)
    p.lineTo(x, y + r)
    p.arcTo(x, y, x + 2 * r, y + 2 * r, 180, 90)
    p.close()
    if fill and stroke:
        c.drawPath(p, fill=1, stroke=1)
    elif fill:
        c.drawPath(p, fill=1, stroke=0)
    else:
        c.drawPath(p, fill=0, stroke=1)
    c.restoreState()


def wrap_text(c, text, font, size, max_width):
    """Simple word wrap returning list of lines."""
    words = text.split()
    lines, cur = [], ""
    for w in words:
        test = (cur + " " + w).strip()
        if c.stringWidth(test, font, size) <= max_width:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def draw_paragraph(c, text, x, y, max_width, font="Helvetica", size=7.5,
                   leading=9.5, color=DARK, max_lines=None):
    """Draw wrapped paragraph; returns y after last line (bottom)."""
    c.setFont(font, size)
    c.setFillColor(color)
    lines = wrap_text(c, text, font, size, max_width)
    if max_lines is not None:
        lines = lines[:max_lines]
    for i, line in enumerate(lines):
        c.drawString(x, y - i * leading, line)
    return y - (len(lines) - 1) * leading - leading


def draw_bullets(c, items, x, y, max_width, font="Helvetica", size=7.2,
                 leading=9.2, color=DARK, bullet="•"):
    c.setFillColor(color)
    for item in items:
        c.setFont(font, size)
        # first line with bullet
        prefix = f"{bullet} "
        avail = max_width - c.stringWidth(prefix, font, size)
        lines = wrap_text(c, item, font, size, avail)
        for i, line in enumerate(lines):
            if i == 0:
                c.drawString(x, y, prefix + line)
            else:
                c.drawString(x + c.stringWidth(prefix, font, size), y, line)
            y -= leading
        y -= 1.2  # small gap between bullets
    return y


def draw_flow_box(c, x, y, w, h, text, fill=SOFT):
    draw_rounded_rect(c, x, y, w, h, 4, fill=fill, stroke=NAVY, sw=0.8)
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 6.5)
    # center multi-line
    lines = wrap_text(c, text, "Helvetica-Bold", 6.5, w - 8)
    total_h = len(lines) * 8
    ty = y + h / 2 + total_h / 2 - 7
    for line in lines:
        tw = c.stringWidth(line, "Helvetica-Bold", 6.5)
        c.drawString(x + (w - tw) / 2, ty, line)
        ty -= 8


def draw_arrow_head(c, tip_x, tip_y, base_y, half=3.2):
    """Small filled triangle pointing down (for vertical flow)."""
    path = c.beginPath()
    path.moveTo(tip_x, tip_y)
    path.lineTo(tip_x - half, base_y)
    path.lineTo(tip_x + half, base_y)
    path.close()
    c.drawPath(path, fill=1, stroke=0)


def section_header(c, x, y, w, title):
    """Colored bar header."""
    draw_rounded_rect(c, x, y - 2, w, 14, 3, fill=NAVY)
    c.setFillColor(WHITE)
    c.setFont("Helvetica-Bold", 8)
    c.drawString(x + 6, y + 1.5, title)
    return y - 10


def build_poster():
    c = canvas.Canvas(str(OUT_PDF), pagesize=(PAGE_W, PAGE_H))
    m = 14  # outer margin

    # Background
    c.setFillColor(LIGHT)
    c.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)

    # Top banner
    banner_h = 58
    c.setFillColor(NAVY)
    c.rect(0, PAGE_H - banner_h, PAGE_W, banner_h, fill=1, stroke=0)
    # accent stripe
    c.setFillColor(ACCENT)
    c.rect(0, PAGE_H - banner_h - 4, PAGE_W, 4, fill=1, stroke=0)

    # Title
    c.setFillColor(WHITE)
    c.setFont("Helvetica-Bold", 16)
    title = "VocalBridge: Low-Cost Subvocal EMG Communication"
    c.drawString(m + 4, PAGE_H - 26, title)
    c.setFont("Helvetica-Bold", 12)
    c.drawString(m + 4, PAGE_H - 42, "for Non-Verbal Individuals Using Edge AI")

    c.setFont("Helvetica", 7.5)
    c.setFillColor(HexColor("#C5D8E6"))
    c.drawRightString(
        PAGE_W - m,
        PAGE_H - 22,
        "vivo Ignite 2026  |  Tech for Good",
    )
    c.drawRightString(
        PAGE_W - m,
        PAGE_H - 34,
        "Grade 8  |  Prototype Category",
    )
    c.drawRightString(
        PAGE_W - m,
        PAGE_H - 46,
        "Author: Nimit Joshi  |  Grade 8  |  School: [Your School]",
    )

    # Layout grid: 3 columns
    top = PAGE_H - banner_h - 14
    gap = 8
    col_w = (PAGE_W - 2 * m - 2 * gap) / 3
    x1 = m
    x2 = m + col_w + gap
    x3 = m + 2 * (col_w + gap)
    bottom = 28
    col_h = top - bottom

    # ========== COLUMN 1 ==========
    y = top
    # INTRODUCTION
    y = section_header(c, x1, y, col_w, "INTRODUCTION")
    y -= 6
    intro = (
        "People with speech loss from ALS, stroke, or vocal-cord damage often depend on "
        "eye-tracking devices or letter boards costing Rs 1.5 lakh to several lakhs. "
        "Most Indian families cannot afford real-time assistive speech. Even when sound "
        "cannot be produced, the brain still sends motor signals to throat and jaw muscles. "
        "Those silent micro-movements — subvocal electromyography (EMG) — can be measured "
        "on the skin and classified into words."
    )
    y = draw_paragraph(c, intro, x1 + 4, y, col_w - 8, size=7.0, leading=8.8)
    y -= 8

    # OBJECTIVE
    y = section_header(c, x1, y, col_w, "OBJECTIVE")
    y -= 6
    objs = [
        "Build a wearable neckband that classifies 5 silent emergency words from throat EMG.",
        "Keep total hardware cost under Rs 2,500 using India-available parts.",
        "Use multi-channel sensing, noise rejection, and a confidence gate for safe output.",
        "Align with SDG 3, SDG 10, and Sugamya Bharat Abhiyan (Accessible India).",
    ]
    y = draw_bullets(c, objs, x1 + 4, y, col_w - 8, size=7.0, leading=8.8)
    y -= 6

    # PROBLEM SNAPSHOT box
    box_h = 72
    draw_rounded_rect(c, x1, y - box_h, col_w, box_h, 5, fill=SOFT, stroke=TEAL, sw=1)
    c.setFillColor(TEAL)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawString(x1 + 6, y - 12, "WHY IT MATTERS")
    c.setFillColor(DARK)
    c.setFont("Helvetica", 6.8)
    facts = [
        "• Commercial AAC devices: Rs 1.5L – 5L+",
        "• VocalBridge target BOM: ~Rs 2,050–2,500",
        "• ~100x cost reduction goal",
        "• Vocabulary V1: Help, Yes, No, Water, Pain",
        "• Theme: Tech for Good + accessibility",
    ]
    fy = y - 24
    for f in facts:
        c.drawString(x1 + 6, fy, f)
        fy -= 9.5
    y = y - box_h - 8

    # SDG
    y = section_header(c, x1, y, col_w, "SDG & NATIONAL ALIGNMENT")
    y -= 6
    sdgs = [
        "SDG 3 — Good Health: assistive communication pathway for speech disability.",
        "SDG 10 — Reduced Inequalities: democratize access via ultra-low cost.",
        "Sugamya Bharat Abhiyan: technology access for Persons with Disabilities.",
    ]
    y = draw_bullets(c, sdgs, x1 + 4, y, col_w - 8, size=6.8, leading=8.5)

    # ========== COLUMN 2 ==========
    y = top
    y = section_header(c, x2, y, col_w, "METHODOLOGY")
    y -= 6
    method_intro = (
        "VocalBridge combines surface EMG sensing, wireless edge hardware, digital signal "
        "processing, and a small neural classifier. Scope is deliberately limited to five "
        "life-critical words so results stay honest and reproducible."
    )
    y = draw_paragraph(c, method_intro, x2 + 4, y, col_w - 8, size=7.0, leading=8.8)
    y -= 10

    # Flow diagram title
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawString(x2 + 4, y, "SYSTEM PIPELINE")
    y -= 8

    # Vertical flow boxes
    stages = [
        "3-channel throat electrodes (submental + laryngeal + ref)",
        "AD8232 differential amplifiers (battery isolated)",
        "ESP32 samples ~200 Hz + BLE transmit",
        "Notch 50 Hz + band-pass 20–450 Hz + artifact reject",
        "Sliding window + 1D-CNN + confidence ≥ 80%",
        "Phone/laptop: on-screen word + text-to-speech",
    ]
    box_h = 22
    for i, st in enumerate(stages):
        draw_flow_box(c, x2 + 10, y - box_h, col_w - 20, box_h, st, fill=WHITE if i % 2 == 0 else SOFT)
        if i < len(stages) - 1:
            # down arrow
            c.setStrokeColor(TEAL)
            c.setFillColor(TEAL)
            c.setLineWidth(1)
            ax = x2 + col_w / 2
            c.line(ax, y - box_h, ax, y - box_h - 5)
            draw_arrow_head(c, ax, y - box_h - 9, y - box_h - 5, half=3.2)
        y -= box_h + 8

    y -= 4
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawString(x2 + 4, y, "KEY INNOVATIONS")
    y -= 10
    innov = [
        "Subvocal word classes — not simple on/off hand gestures.",
        "Multi-channel common-mode rejection for neck noise.",
        "Confidence-based rejection (silence > wrong word).",
        "2-minute personal calibration for new users.",
        "India retail BOM under Rs 2,500.",
    ]
    y = draw_bullets(c, innov, x2 + 4, y, col_w - 8, size=6.8, leading=8.5)

    # ========== COLUMN 3 ==========
    y = top
    y = section_header(c, x3, y, col_w, "EXPECTED RESULTS / HYPOTHESES")
    y -= 6
    results = [
        "Raw multi-channel EMG will visibly change when silently mouthing different words.",
        "After filtering, a classifier can separate a small vocabulary better than chance.",
        "Artifact rules will reduce false triggers from swallowing and head motion.",
        "Confidence gating will trade some recall for safer communication.",
        "Full demo path: silent 'Help' → spoken 'Help' within ~0.5–1 s latency target.",
    ]
    y = draw_bullets(c, results, x3 + 4, y, col_w - 8, size=6.9, leading=8.6)
    y -= 6

    # Budget mini table
    y = section_header(c, x3, y, col_w, "BUDGET (STARTER BOM)")
    y -= 4
    rows = [
        ("ESP32 DevKit", "350"),
        ("AD8232 modules x3", "750"),
        ("Electrodes + strap + wires", "500"),
        ("LiPo + charger + misc.", "450"),
        ("TOTAL (approx.)", "Rs 2,050"),
    ]
    # header
    c.setFillColor(TEAL)
    c.rect(x3, y - 12, col_w, 12, fill=1, stroke=0)
    c.setFillColor(WHITE)
    c.setFont("Helvetica-Bold", 7)
    c.drawString(x3 + 4, y - 9, "Component")
    c.drawRightString(x3 + col_w - 4, y - 9, "Rs")
    y -= 12
    for i, (name, price) in enumerate(rows):
        bg = WHITE if i % 2 == 0 else SOFT
        if name.startswith("TOTAL"):
            bg = HexColor("#D8F0EB")
        c.setFillColor(bg)
        c.rect(x3, y - 11, col_w, 11, fill=1, stroke=0)
        c.setStrokeColor(HexColor("#D0D7DE"))
        c.setLineWidth(0.3)
        c.line(x3, y - 11, x3 + col_w, y - 11)
        c.setFillColor(DARK)
        font = "Helvetica-Bold" if name.startswith("TOTAL") else "Helvetica"
        c.setFont(font, 6.8)
        c.drawString(x3 + 4, y - 8, name)
        c.drawRightString(x3 + col_w - 4, y - 8, price)
        y -= 11
    y -= 8

    # Timeline
    y = section_header(c, x3, y, col_w, "10-WEEK PLAN")
    y -= 6
    timeline = [
        "W1–2: Hardware + raw signal check",
        "W3–4: Dataset (reps x 5 words)",
        "W5: Filters + features + artifacts",
        "W6–7: Train ML + confusion matrix",
        "W8: Real-time BLE + TTS demo",
        "W9–10: Calibration, polish, Q&A",
    ]
    y = draw_bullets(c, timeline, x3 + 4, y, col_w - 8, size=6.8, leading=8.4)
    y -= 6

    # Safety
    y = section_header(c, x3, y, col_w, "SAFETY & LIMITATIONS")
    y -= 6
    safety = [
        "Battery / power-bank isolation only while on skin.",
        "Surface electrodes only; research demo, not a medical device.",
        "V1 limits: 5 words, per-user calibration, placement sensitivity.",
        "Failures documented; vocabulary reduced if needed.",
    ]
    y = draw_bullets(c, safety, x3 + 4, y, col_w - 8, size=6.7, leading=8.3)

    # ========== BOTTOM BAR: CONCLUSION + BIBLIOGRAPHY ==========
    bot_y = 8
    bot_h = 78
    draw_rounded_rect(c, m, bot_y, PAGE_W - 2 * m, bot_h, 5, fill=WHITE, stroke=NAVY, sw=1)

    # split bottom
    left_w = (PAGE_W - 2 * m) * 0.62
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 8)
    c.drawString(m + 8, bot_y + bot_h - 14, "CONCLUSION & IMPACT")
    conc = (
        "VocalBridge turns residual throat muscle activity into a few emergency spoken words "
        "using multi-channel EMG, edge wireless hardware, and confidence-gated AI — at roughly "
        "textbook-set cost instead of luxury medical hardware. The work is scoped like real "
        "research: limited vocabulary, honest metrics, safety first, and a clear path to expand. "
        "If successful, it offers a practical communication bridge for non-verbal users and a "
        "template for affordable assistive tech in India."
    )
    draw_paragraph(
        c, conc, m + 8, bot_y + bot_h - 26, left_w - 16,
        size=6.6, leading=8.2, color=DARK, max_lines=5
    )

    # vertical divider
    c.setStrokeColor(SOFT)
    c.setLineWidth(1)
    div_x = m + left_w
    c.line(div_x, bot_y + 8, div_x, bot_y + bot_h - 8)

    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 8)
    c.drawString(div_x + 8, bot_y + bot_h - 14, "BIBLIOGRAPHY / PRIOR ART")
    refs = [
        "MIT Media Lab AlterEgo (subvocal HCI research)",
        "NASA / related work on subvocal speech interfaces",
        "Clinical surface-EMG signal processing literature",
        "UN SDGs 3 & 10; Sugamya Bharat Abhiyan",
        "Student contribution: low-cost multi-channel design,",
        "  confidence gating, India BOM, honest 5-word scope",
    ]
    c.setFont("Helvetica", 6.3)
    c.setFillColor(MUTED)
    ry = bot_y + bot_h - 26
    for r in refs:
        c.drawString(div_x + 8, ry, "• " + r if not r.startswith(" ") else r)
        ry -= 8.2

    # Footer thin line
    c.setFillColor(NAVY)
    c.rect(0, 0, PAGE_W, 6, fill=1, stroke=0)
    c.setFillColor(ACCENT)
    c.rect(0, 6, PAGE_W, 2, fill=1, stroke=0)

    c.save()
    print(f"Wrote {OUT_PDF}")

    # Also export PNG via pymupdf for portal JPEG/PNG option
    try:
        import fitz
        doc = fitz.open(str(OUT_PDF))
        page = doc[0]
        # high res for quality, then we may compress
        pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)
        pix.save(str(OUT_PNG))
        print(f"Wrote {OUT_PNG} {pix.width}x{pix.height}")
        doc.close()
    except Exception as e:
        print("PNG export failed:", e)


if __name__ == "__main__":
    build_poster()
