/*
 * VocalBridge — CLENCH DETECTOR v10 (ARMED / FIRED / SETTLE state machine)
 * ------------------------------------------------------------------------
 * v9 fired on real clenches (your dev hit 682!) BUT also flagged every
 * hand/arm wiggle between squeezes, because to the AD8232 any muscle
 * movement looks like a clench. v10 fixes that with a proper state
 * machine:
 *
 *   ARMED  -> waiting. (squeeze and hold 2 s)
 *   RISING -> signal above threshold, counting...
 *   FIRED  -> prints ">>> CLENCH! <<<" ONCE.
 *   SETTLE -> ignores everything until your arm is calm ~1.2 s,
 *             then re-arms automatically.
 *
 * So it fires exactly once per squeeze and CANNOT fire while you are
 * shuffling/moving — it's disarmed until it sees you relax.
 *
 * Board:  ESP32 Dev Module
 * Wiring: AD8232 3.3V->3V3, GND->GND, OUTPUT->GPIO34
 * Baud:   115200 (Serial Monitor)
 *
 * DEMO PROTOCOL (this is the trick for clean results):
 *   1) Arm FLAT and still on the table. Sit still 5 s while it learns.
 *   2) It prints ">>> ARMED". NOW: squeeze a soft ball (or hard fist)
 *      and HOLD 2-3 s, then FULLY relax and keep still.
 *   3) Wait for the next ">>> ARMED" before the next squeeze.
 *      Squeeze only with the fingers — don't lift or shift the arm.
 */

const int SENSOR_PIN = 34;
const int BAUD = 115200;

const int N = 60;               // 60 samples * 10ms = 0.6 s per line
const int LEARN_MS = 5000;      // 5 s calibration window
const int MAX_LEARN = 16;       // stored learning samples
const int FIRE_STREAK = 2;      // ~1.2 s held above threshold -> fire
const int SETTLE_LINES = 2;     // ~1.2 s of calm required before re-arming

int learnSamples[MAX_LEARN];
int learnCount = 0;
unsigned long learnStart = 0;

float baseline = 0;
int THRESHOLD = 200;
bool learned = false;

enum State { ST_ARMED, ST_RISING, ST_SETTLE };
State state = ST_ARMED;
int streak = 0;
int quietStreak = 0;
int sessionMaxDev = 0;

void setup() {
  Serial.begin(BAUD);
  delay(800);
  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);

  Serial.println("VocalBridge_ClenchDetector_v10 (ARMED/FIRED/SETTLE)");
  Serial.println("SIT STILL 5 s (arm FLAT). Learning...");
  Serial.println();
  learnStart = millis();
}

int readAvg() {
  long sum = 0;
  for (int i = 0; i < N; i++) {
    sum += analogRead(SENSOR_PIN);
    delay(10);
  }
  return (int)(sum / N);
}

void sortArr(int *a, int n) {
  for (int i = 1; i < n; i++) {
    int v = a[i];
    int j = i - 1;
    while (j >= 0 && a[j] > v) { a[j + 1] = a[j]; j--; }
    a[j + 1] = v;
  }
}

void loop() {
  int avg = readAvg();

  // ---------------- CALIBRATION ----------------
  if (!learned) {
    if (learnCount < MAX_LEARN) learnSamples[learnCount++] = avg;

    Serial.print("learning ");
    Serial.print((millis() - learnStart) / 1000);
    Serial.print("s  avg=");
    Serial.println(avg);

    if (millis() - learnStart >= LEARN_MS && learnCount >= 8) {
      int sorted[MAX_LEARN];
      for (int i = 0; i < learnCount; i++) sorted[i] = learnSamples[i];
      sortArr(sorted, learnCount);

      int med = sorted[learnCount / 2];
      baseline = med;

      int devs[MAX_LEARN];
      for (int i = 0; i < learnCount; i++) {
        int d = sorted[i] - med;
        if (d < 0) d = -d;
        devs[i] = d;
      }
      sortArr(devs, learnCount);
      int mad = devs[learnCount / 2];

      THRESHOLD = mad * 4;
      if (THRESHOLD < 150) THRESHOLD = 150;
      if (THRESHOLD > 2000) THRESHOLD = 2000;

      learned = true;
      state = ST_ARMED;
      streak = 0;
      quietStreak = 0;

      Serial.println();
      Serial.print(">>> LEARNED: baseline = "); Serial.print(med);
      Serial.print(", rest noise = "); Serial.print(mad);
      Serial.print(", threshold = "); Serial.println(THRESHOLD);
      Serial.println(">>> ARMED — squeeze and hold 2-3 s, then relax fully.");
      Serial.println();
    }
    return;
  }

  // ---------------- RUNNING ----------------
  int dev = avg - (int)baseline;
  int absDev = dev < 0 ? -dev : dev;

  if (absDev > sessionMaxDev) sessionMaxDev = absDev;

  // slow drift tracking only while relaxed
  if (streak == 0 && quietStreak == 0) {
    baseline = baseline * 0.998 + avg * 0.002;
  }

  bool above = absDev > THRESHOLD;

  switch (state) {
    case ST_ARMED:
      if (above) {
        streak++;
        if (streak >= FIRE_STREAK) {
          Serial.println(">>> CLENCH! <<<");
          state = ST_SETTLE;
          quietStreak = 0;
          streak = 0;
        } else {
          state = ST_RISING;
        }
      }
      break;

    case ST_RISING:
      if (above) {
        streak++;
        if (streak >= FIRE_STREAK) {
          Serial.println(">>> CLENCH! <<<");
          state = ST_SETTLE;
          quietStreak = 0;
          streak = 0;
        }
      } else {
        // too short / dropped -> back to armed, not a real squeeze
        state = ST_ARMED;
        streak = 0;
      }
      break;

    case ST_SETTLE:
      if (!above) {
        quietStreak++;
        if (quietStreak >= SETTLE_LINES) {
          state = ST_ARMED;
          quietStreak = 0;
          Serial.println(">>> ARMED — squeeze now.");
        }
      } else {
        quietStreak = 0;   // still moving -> restart the calm count
      }
      break;
  }

  // one diagnostic line
  const char *st = state == ST_ARMED ? "ARMED" : (state == ST_RISING ? "RISING" : "SETTLE");
  Serial.print("avg="); Serial.print(avg);
  Serial.print("  dev="); Serial.print(dev);
  Serial.print("  thr="); Serial.print(THRESHOLD);
  Serial.print("  state="); Serial.print(st);
  Serial.print("  MAXdev="); Serial.print(sessionMaxDev);
  Serial.println(above ? "  [above]" : "");
}
