/*
 * VocalBridge — MUSCLE TEST v3 (with CONTACT QUALITY score)
 * ----------------------------------------------------------
 * Purpose: Like v2, but it COUNTS how many samples each second hit the
 *          rails (0 or 4095). Those rail hits = loose/floating wires.
 *
 * Board:  ESP32 Dev Module
 * Wiring: AD8232 3.3V -> 3V3, GND -> GND, OUTPUT -> GPIO34
 * Baud:   115200 (Serial Monitor)
 *
 * HOW TO READ IT:
 *   contact=100%   -> wires are solid. Look at min/max: a tight band = clean signal.
 *   contact<90%    -> wires still loose/floating. SOLDER THE HEADERS.
 *
 * GOAL (after soldering):
 *   At rest:   avg~2047, min~2000, max~2100, contact=100%   (NO 0, NO 4095)
 *   Clench:    avg/min/max jump clearly, then return when you relax.
 */

const int SENSOR_PIN = 34;
const int BAUD = 115200;

void setup() {
  Serial.begin(BAUD);
  delay(800);

  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);

  Serial.println("VocalBridge_MuscleTest_v3 (contact quality)");
  Serial.println("Sit still (rest), then CLENCH hard, then relax.");
  Serial.println("Watch the contact% and the min/max values.");
  Serial.println();
}

void loop() {
  const int N = 100;        // 100 samples per second
  long sum = 0;
  int mn = 4096, mx = -1;
  int dropouts = 0;         // samples stuck at the rails = lost contact

  for (int i = 0; i < N; i++) {
    int v = analogRead(SENSOR_PIN);
    sum += v;
    if (v < mn) mn = v;
    if (v > mx) mx = v;
    if (v <= 5 || v >= 4090) dropouts++;   // railed = floating/loose wire
    delay(10);
  }

  int avg = (int)(sum / N);
  int contact = 100 - (dropouts * 100 / N);   // 100% = perfect contact

  Serial.print("avg="); Serial.print(avg);
  Serial.print("  min="); Serial.print(mn);
  Serial.print("  max="); Serial.print(mx);
  Serial.print("  contact="); Serial.print(contact); Serial.print("%");

  if (dropouts > 0) {
    Serial.print("  (rail hits: "); Serial.print(dropouts); Serial.print(")");
  }
  Serial.println();

  if (contact < 90) {
    Serial.println("  >>> BAD CONTACT - wires still loose. SOLDER the headers, then retest.");
  } else if ((mx - mn) < 200) {
    Serial.println("  -> TIGHT & CLEAN signal. Great! Now CLENCH and watch the values jump.");
  } else {
    Serial.println("  -> Good contact, signal moving (you are probably moving/clenching).");
  }

  Serial.println();
}
