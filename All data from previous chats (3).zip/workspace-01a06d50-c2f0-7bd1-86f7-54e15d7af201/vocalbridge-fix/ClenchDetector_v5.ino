/*
 * VocalBridge — CLENCH DETECTOR (same AD8232, no new parts)
 * ----------------------------------------------------------
 * The AD8232 filters out fast EMG spikes, BUT it passes the SLOW
 * baseline shift that happens when your muscle bulges under the pads
 * during a clench. That shift is what moved your average by hundreds
 * of counts when you pressed the pads. So we detect THAT.
 *
 * Board:  ESP32 Dev Module
 * Wiring: AD8232 3.3V->3V3, GND->GND, OUTPUT->GPIO34
 *         (optional) LO+->GPIO32, LO-->GPIO33
 * Baud:   115200 (Serial Monitor)
 *
 * HOW TO USE:
 *   1) Stick pads: red+yellow on the forearm MUSCLE BELLY, green on
 *      the elbow bone. Sit COMPLETELY still for the first 5 seconds
 *      while it learns your rest baseline.
 *   2) Then CLENCH HARD and HOLD 2-3 seconds, then relax. Repeat.
 *   3) When the average swings far enough from baseline, it prints
 *      "CLENCH!" — later we wire that to the speaker + "HELP".
 *
 * CALIBRATION (the only thing you'll tune):
 *   Watch the "dev" number. At rest it should be small (near 0).
 *   While clenching it should be bigger. Set THRESHOLD to about
 *   HALF of the clench dev value (e.g. rest dev ~20, clench dev ~200
 *   -> THRESHOLD 100). Then it fires reliably on clench, never at rest.
 */

const int SENSOR_PIN   = 34;
const int LO_PLUS_PIN  = 32;   // optional
const int LO_MINUS_PIN = 33;   // optional
const int BAUD = 115200;

int THRESHOLD = 100;          // <<< tune this after watching "dev"

const int WINDOW_SAMPLES = 50;  // 50 samples * 10ms = 0.5 s per line
const int STREAK_ON  = 2;       // 2 lines (~1 s) above threshold = a clench
const int STREAK_OFF = 4;       // 4 lines (~2 s) below = clench ended
const int COOLDOWN_MS = 2000;   // ignore repeats after a detection

float baseline = -1;            // learned during first 5 seconds
bool clenchActive = false;
int streak = 0;
unsigned long lastFireMs = 0;

void setup() {
  Serial.begin(BAUD);
  delay(800);
  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);
  pinMode(LO_PLUS_PIN, INPUT_PULLUP);
  pinMode(LO_MINUS_PIN, INPUT_PULLUP);

  Serial.println("VocalBridge_ClenchDetector_v5");
  Serial.println("SIT STILL for 5s (learning baseline)...");
  Serial.println("Then CLENCH HARD + HOLD, relax, repeat.");
  Serial.println();
}

void loop() {
  long sum = 0;
  int mn = 4096, mx = -1;
  long madSum = 0;

  for (int i = 0; i < WINDOW_SAMPLES; i++) {
    int v = analogRead(SENSOR_PIN);
    sum += v;
    if (v < mn) mn = v;
    if (v > mx) mx = v;
    delay(10);
  }

  int avg = (int)(sum / WINDOW_SAMPLES);

  // burst energy (mean absolute deviation around the window mean)
  // (recompute with a quick second pass on the saved data is overkill
  //  here; instead we use min/max spread as a cheap energy proxy)
  int spread = mx - mn;

  // ---- learn baseline during the first 5 seconds ----
  if (millis() < 5000) {
    if (baseline < 0) baseline = avg;
    baseline = baseline * 0.90 + avg * 0.10;   // settle onto rest value
    Serial.print("learning... avg="); Serial.print(avg);
    Serial.print("  baseline="); Serial.println((int)baseline);
    return;
  }

  // ---- track baseline slowly ONLY while relaxed (so it doesn't chase the clench) ----
  int dev = avg - (int)baseline;
  int absDev = dev < 0 ? -dev : dev;

  if (!clenchActive) {
    baseline = baseline * 0.995 + avg * 0.005;   // very slow drift tracking
  }

  // ---- state machine ----
  bool above = absDev > THRESHOLD;

  if (above) {
    streak++;
    if (streak >= STREAK_ON && !clenchActive) {
      if (millis() - lastFireMs > (unsigned long)COOLDOWN_MS) {
        Serial.println(">>> CLENCH! <<<");
        lastFireMs = millis();
      }
      clenchActive = true;
    }
  } else {
    streak = 0;
    if (clenchActive) {
      streak--;
      // (falls through STREAK_OFF naturally below)
    }
  }

  if (clenchActive && !above) {
    if (streak <= -STREAK_OFF) clenchActive = false;
  }

  // ---- print one calibration line ----
  bool laOff = digitalRead(LO_PLUS_PIN) == HIGH;
  bool raOff = digitalRead(LO_MINUS_PIN) == HIGH;

  Serial.print("avg="); Serial.print(avg);
  Serial.print("  baseline="); Serial.print((int)baseline);
  Serial.print("  dev="); Serial.print(dev);
  Serial.print("  spread="); Serial.print(spread);
  Serial.print("  thr="); Serial.print(THRESHOLD);
  Serial.print("  leads="); Serial.print(laOff ? "Y!" : "y"); Serial.print(raOff ? "R!" : "r");
  Serial.println(clenchActive ? "  [CLENCHING]" : "");

  delay(0);
}
