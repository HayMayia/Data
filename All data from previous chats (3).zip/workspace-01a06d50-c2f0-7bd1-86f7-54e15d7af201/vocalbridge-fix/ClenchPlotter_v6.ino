/*
 * VocalBridge — CLENCH PLOTTER (numbers only, for the Serial Plotter)
 * -------------------------------------------------------------------
 * Purpose: SEE the clench as a graph, so you can choose the threshold
 *          visually before we hard-code it.
 *
 * Board:  ESP32 Dev Module
 * Wiring: AD8232 3.3V->3V3, GND->GND, OUTPUT->GPIO34
 * Baud:   115200
 *
 * HOW TO USE:
 *   1) Tools -> Serial Plotter  (set 115200 baud at bottom-left)
 *   2) Sit COMPLETELY still for the first 5 s (it learns baseline).
 *   3) Then CLENCH HARD and HOLD 2-3 s, relax, repeat.
 *
 * WHAT YOU SEE (4 lines):
 *   avg        -> your live smoothed signal (watch THIS move on clench)
 *   base       -> slow baseline (should sit near 2047, barely moving)
 *   hi         -> baseline + THRESHOLD  (upper band edge)
 *   lo         -> baseline - THRESHOLD  (lower band edge)
 *
 *   A clench = the avg line pokes clearly above hi or below lo.
 *
 * TUNE THRESHOLD:
 *   If clench does NOT cross the band -> lower THRESHOLD (e.g. 50).
 *   If avg crosses the band even at rest -> raise THRESHOLD (e.g. 200).
 */

const int SENSOR_PIN = 34;
const int BAUD = 115200;

int THRESHOLD = 100;             // <<< change this until clench crosses, rest does not
const int N = 20;                // samples per printed line (20 * 10ms = 0.2 s)

float baseline = -1;

void setup() {
  Serial.begin(BAUD);
  delay(800);
  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);

  // Plotter legend (first line, no commas in labels)
  Serial.println("avg,base,hi,lo");
}

void loop() {
  long sum = 0;
  for (int i = 0; i < N; i++) {
    sum += analogRead(SENSOR_PIN);
    delay(10);
  }
  int avg = (int)(sum / N);

  if (baseline < 0) baseline = avg;                 // first sample -> baseline
  else if (millis() < 5000) {
    baseline = baseline * 0.90 + avg * 0.10;        // settle during first 5 s
  } else {
    baseline = baseline * 0.995 + avg * 0.005;      // slow drift tracking
  }

  int hi = (int)(baseline + THRESHOLD);
  int lo = (int)(baseline - THRESHOLD);

  // Numbers only: avg,base,hi,lo
  Serial.print(avg);
  Serial.print(',');
  Serial.print((int)baseline);
  Serial.print(',');
  Serial.print(hi);
  Serial.print(',');
  Serial.println(lo);
}
