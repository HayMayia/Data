# VocalBridge — Progress Log (where we left off)

Updated: night of 4 Sep 2026. Next session: after SST exam week.

## ✅ DONE — the 4095 saga (solved)
- Root cause of "stuck at 4095": OUTPUT wire floating / not connected (poke-in wires),
  then later a loose cable. Soldered headers fixed it.
- Healthy AD8232 @3.3V reads ~2047 (1.65V) at rest — this was our "green light".

## ✅ DONE — electrodes
- Green/RL -> elbow bone (required! without it, DC leads-off mode reports both pads OFF).
- Red/RA + Yellow/LA -> same forearm muscle belly.
- LO+/LO- confirmed leads-off detection works (wired LO+->GPIO32, LO-->GPIO33).

## ✅ DONE — muscle detection (the big win)
- AD8232 filters out fast EMG (it's an ECG chip), BUT the SLOW baseline shift from a
  clench IS visible: dev swung to **682** counts vs rest noise ~39.
- Working sketch: **ClenchDetector_v10.ino** (ARMED / RISING / SETTLE state machine,
  auto-calibrates baseline+threshold via median/MAD). Fires ">>> CLENCH! <<<" once per
  held squeeze, then re-arms after ~1.2s of calm.
- NOTE: v10 compiles — renamed enum to ST_ARMED/ST_RISING/ST_SETTLE (RISING collides
  with Arduino.h #define RISING 0x01).
- Demo protocol: arm flat+still, squeeze ball/fist with fingers only, hold 2-3s,
  fully relax, wait for ">>> ARMED".

## ⏭️ NEXT STEPS (in order)
1. Run v10 once, confirm one clean ARMED -> CLENCH! -> SETTLE -> ARMED cycle.
2. Wire CLENCH! -> speaker/TTS: squeeze = phone/laptop says "HELP".
   (existing python/help_tts_listener.py + Phase1_HELP.ino pattern in workspace_extracted/)
3. Move to the real VocalBridge goal: jaw clench / swallow / tongue press with pads
   under the chin — see if those produce a usable dev too.
4. Then package updates: BOM, build guide, poster, report, video script (all exist
   in workspace_extracted/ from the earlier session).

## Files (this session)
/home/user/vocalbridge-fix/
- ADC_SelfTest.ino            (prove ESP32 ADC works)
- VocalBridge_MuscleTest_v2.ino  (auto 4095/2048 diagnosis)
- VocalBridge_MuscleTest_v3.ino  (contact-quality %)
- VocalBridge_MuscleTest_v4.ino  (leads-off LO+/LO- detector)
- ClenchDetector_v5.ino       (fixed threshold — too sensitive, retired)
- ClenchDetector_v6.ino       (plotter version: avg,base,hi,lo)
- ClenchDetector_v7.ino       (auto-cal v1 — BUG: threshold 5184, retired)
- ClenchDetector_v8.ino       (auto-cal v2 — BUG: max-wobble, threshold 828, retired)
- ClenchDetector_v9.ino       (median/MAD cal, works)
- ClenchDetector_v10.ino      (state machine, WORKS — use this)
- VocalBridge_4095_FIX.md     (full hardware fix guide)
