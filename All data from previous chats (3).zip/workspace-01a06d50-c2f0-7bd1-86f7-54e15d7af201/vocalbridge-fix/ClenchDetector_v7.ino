/*
 * VocalBridge — CLENCH DETECTOR v7 (AUTO-CALIBRATING)
 * ----------------------------------------------------
 * v5 fired on every line because THRESHOLD was a fixed 100, and your
 * natural motion noise is bigger than that. This version FIXES it:
 *
 *   - First 5 seconds: sit STILL. It measures your rest baseline AND
 *     your rest noise.
 *   - It then sets THRESHOLD = 3x your rest noise, so rest stays below
 *     the bar and only a real deliberate clench crosses it.
 *
 * Board:  ESP32 Dev Module
 * Wiring: AD8232 3.3V->3V3, GND->GND, OUTPUT->GPIO34
 * Baud:   115200 (Serial Monitor)
 *
 * HOW TO USE:
 *   1) Upload. Sit COMPLETELY still (arm relaxed on table) for 5 s.
 *   2) It prints: "Learned baseline ... threshold ..."
 *   3) Then CLENCH HARD and HOLD ~2 s, relax, repeat.
 *   4) ">>> CLENCH! <<<" prints only on a real sustained clench.
 */

const int SENSOR_PIN = 34;
const int BAUD = 115200;

const int N = 50;                 // samples per line (50 * 10ms = 0.5 s)
const int LEARN_MS = 5000;        // calibration window
const int FIRE_STREAK = 3;        // 3 lines (~1.5 s) above threshold to fire
const int COOLDOWN_MS = 2500;     // ignore repeats after a detection

float baseline = 0;
int restMaxDev = 0;
int THRESHOLD = 100;              // will be overwritten by auto-calibration

bool learned = false;
int aboveStreak = 0;
unsigned long lastFireMs = 0;

void setup() {
  Serial.begin(BAUD);
  delay(800);
  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);

  Serial.println("VocalBridge_ClenchDetector_v7 (auto-calibrating)");
  Serial.println("SIT STILL for 5 s while it learns...");
  Serial.println();
}

void loop() {
  long sum = 0;
  for (int i = 0; i < N; i++) {
    sum += analogRead(SENSOR_PIN);
    delay(10);
  }
  int avg = (int)(sum / N);

  // ---------- calibration phase (first 5 s) ----------
  if (!learned) {
    baseline = baseline * 0.90 + avg * 0.10;
    int dev = avg - (int)baseline;
    if (dev < 0) dev = -dev;
    if (dev > restMaxDev) restMaxDev = dev;

    Serial.print("learning... avg="); Serial.print(avg);
    Serial.print("  baseline="); Serial.print((int)baseline);
    Serial.print("  restNoise="); Serial.println(restMaxDev);

    if (millis() > LEARN_MS) {
      learned = true;
      // 3x rest noise, with a floor so it never becomes too twitchy
      THRESHOLD = restMaxDev * 3;
      if (THRESHOLD < 80) THRESHOLD = 80;

      Serial.println();
      Serial.print(">>> LEARNED: baseline ~"); Serial.print((int)baseline);
      Serial.print(", rest noise ~"); Serial.print(restMaxDev);
      Serial.print(", threshold = "); Serial.println(THRESHOLD);
      Serial.println(">>> Now CLENCH HARD and HOLD ~2 s, then relax.");
      Serial.println();
    }
    return;
  }

  // ---------- running phase ----------
  int dev = avg - (int)baseline;
  int absDev = dev < 0 ? -dev : dev;

  // slow baseline drift ONLY while not actively clenching
  if (aboveStreak == 0) {
    baseline = baseline * 0.995 + avg * 0.005;
  }

  bool above = absDev > THRESHOLD;
  if (above) {
    aboveStreak++;
  } else {
    aboveStreak = 0;
  }

  // fire exactly once per sustained clench (with cooldown)
  if (aboveStreak == FIRE_STREAK && (millis() - lastFireMs > (unsigned long)COOLDOWN_MS)) {
    Serial.println(">>> CLENCH! <<<");
    lastFireMs = millis();
  }

  // one diagnostic line
  Serial.print("avg="); Serial.print(avg);
  Serial.print("  baseline="); Serial.print((int)baseline);
  Serial.print("  dev="); Serial.print(dev);
  Serial.print("  thr="); Serial.print(THRESHOLD);
  Serial.print("  streak="); Serial.print(aboveStreak);
  Serial.println(above ? "  [above]" : "");
}
