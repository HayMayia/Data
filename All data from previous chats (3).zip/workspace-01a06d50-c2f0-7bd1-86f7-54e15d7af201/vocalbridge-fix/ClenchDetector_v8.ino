/*
 * VocalBridge — CLENCH DETECTOR v8 (FIXED auto-calibration)
 * ----------------------------------------------------------
 * v7 bug: baseline started at 0 and walked up, so "rest noise" was really
 * "distance from zero" (1728!) and threshold became 5184 — impossible to
 * reach on a 0..4095 ADC. FIXED here:
 *
 *   - 5 s of samples are stored, then baseline = their AVERAGE,
 *     rest noise = the biggest wobble around that average.
 *   - threshold = 3x noise (clamped to a sane 80..2000 range).
 *
 * Board:  ESP32 Dev Module
 * Wiring: AD8232 3.3V->3V3, GND->GND, OUTPUT->GPIO34
 * Baud:   115200 (Serial Monitor)
 *
 * HOW TO USE:
 *   1) Upload. Put your arm FLAT on the table and sit COMPLETELY still
 *      for 5 s (it learns your rest level).
 *   2) It prints ">>> LEARNED: baseline ... threshold ..."
 *   3) Try the movements below. A hard, HELD one fires ">>> CLENCH! <<<".
 *      Watch "dev" and "MAXdev" to see which movement is strongest.
 */

const int SENSOR_PIN = 34;
const int BAUD = 115200;

const int N = 40;                 // 40 samples * 10ms = 0.4 s per line
const int LEARN_MS = 5000;        // 5 s calibration window
const int MAX_LEARN = 16;         // stored learning samples
const int FIRE_STREAK = 3;        // 3 lines (~1.2 s) above threshold to fire
const int COOLDOWN_MS = 2500;     // ignore repeats after a detection

int learnSamples[MAX_LEARN];
int learnCount = 0;
unsigned long learnStart = 0;

float baseline = 0;
int restNoise = 0;
int THRESHOLD = 100;
bool learned = false;

int aboveStreak = 0;
int sessionMaxDev = 0;
unsigned long lastFireMs = 0;

void setup() {
  Serial.begin(BAUD);
  delay(800);
  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);

  Serial.println("VocalBridge_ClenchDetector_v8");
  Serial.println("SIT STILL for 5 s (arm FLAT on table). Learning rest level...");
  Serial.println();
  learnStart = millis();
}

int readAvg() {
  long sum = 0;
  for (int i = 0; i < N; i++) {
    sum += analogRead(SENSOR_PIN);
    delay(10);
  }
  return (int)(sum / N);
}

void loop() {
  int avg = readAvg();

  // ---------------- CALIBRATION ----------------
  if (!learned) {
    if (learnCount < MAX_LEARN) learnSamples[learnCount++] = avg;

    Serial.print("learning ");
    Serial.print((millis() - learnStart) / 1000);
    Serial.print("s  avg=");
    Serial.println(avg);

    if (millis() - learnStart >= LEARN_MS && learnCount >= 8) {
      long s = 0;
      for (int i = 0; i < learnCount; i++) s += learnSamples[i];
      baseline = s / (float)learnCount;              // TRUE average

      int mx = 0;
      for (int i = 0; i < learnCount; i++) {
        int d = learnSamples[i] - (int)baseline;
        if (d < 0) d = -d;
        if (d > mx) mx = d;
      }
      restNoise = mx;                                // TRUE wobble

      THRESHOLD = restNoise * 3;
      if (THRESHOLD < 80)   THRESHOLD = 80;
      if (THRESHOLD > 2000) THRESHOLD = 2000;

      learned = true;
      Serial.println();
      Serial.print(">>> LEARNED: baseline = "); Serial.print((int)baseline);
      Serial.print(", rest noise = "); Serial.print(restNoise);
      Serial.print(", threshold = "); Serial.println(THRESHOLD);
      Serial.println(">>> Now try movements. A hard HELD one fires CLENCH!");
      Serial.println();
    }
    return;
  }

  // ---------------- RUNNING ----------------
  int dev = avg - (int)baseline;
  int absDev = dev < 0 ? -dev : dev;

  if (absDev > sessionMaxDev) sessionMaxDev = absDev;   // remembers your best

  if (aboveStreak == 0) {
    baseline = baseline * 0.998 + avg * 0.002;          // very slow drift
  }

  bool above = absDev > THRESHOLD;
  if (above) aboveStreak++;
  else aboveStreak = 0;

  if (aboveStreak == FIRE_STREAK && (millis() - lastFireMs > (unsigned long)COOLDOWN_MS)) {
    Serial.println(">>> CLENCH! <<<");
    lastFireMs = millis();
  }

  Serial.print("avg="); Serial.print(avg);
  Serial.print("  dev="); Serial.print(dev);
  Serial.print("  thr="); Serial.print(THRESHOLD);
  Serial.print("  MAXdev="); Serial.print(sessionMaxDev);
  Serial.println(above ? "  [above]" : "");
}
