/*
 * VocalBridge — ADC SELF-TEST
 * ---------------------------
 * Purpose: PROVE your ESP32 ADC, pin, and code are working BEFORE you blame the AD8232.
 * This takes ~2 minutes and tells you whether the problem is the ESP32 or the sensor wiring.
 *
 * Board:  ESP32 Dev Module
 * Pin:    GPIO34 (change PIN below to 35 if you suspect pin 34)
 * Baud:   115200 (Serial Monitor)
 *
 * HOW TO RUN:
 *   1) Upload with NOTHING connected to GPIO34.
 *      -> numbers should jump around randomly (that's normal noise).
 *   2) Jumper GPIO34 -> GND.  Expect: ~0
 *   3) Jumper GPIO34 -> 3V3.  Expect: ~4095
 *   4) Touch GPIO34 with a bare finger. Expect: big random jumps (mains hum).
 *
 * VERDICT:
 *   - GND gives 0 AND 3V3 gives 4095  -> ESP32 + pin + code are FINE.
 *   - Anything else                   -> wrong pin / bad board / wrong board selected.
 */

const int PIN = 34;      // AD8232 OUTPUT -> GPIO34 (try 35 if in doubt)
const int BAUD = 115200;

void setup() {
  Serial.begin(BAUD);
  delay(800);

  analogReadResolution(12);                 // 12-bit -> 0..4095
  analogSetPinAttenuation(PIN, ADC_11db);   // 0..3.3 V range
  pinMode(PIN, INPUT);

  Serial.println("=== ADC SELF-TEST (GPIO" + String(PIN) + ") ===");
  Serial.println("1) Nothing connected  -> random jumping numbers (normal)");
  Serial.println("2) Jumper to GND      -> expect ~0");
  Serial.println("3) Jumper to 3V3      -> expect ~4095");
  Serial.println("4) Finger on pin      -> big jumps (normal)");
  Serial.println("--- raw,millivolts ---");
}

void loop() {
  int raw = analogRead(PIN);
  float mv = raw / 4095.0 * 3300.0;

  Serial.print(raw);
  Serial.print(",");
  Serial.print((int)mv);
  Serial.println(" mV");

  delay(200);
}
