/*
 * VocalBridge — MUSCLE TEST v4 (LEAD-OFF DETECTOR)
 * ------------------------------------------------
 * Your wiring is soldered and the baseline reads ~2047 (1.65 V) — so power,
 * sensor, and connection are all WORKING. The remaining puzzle is
 * "min=0 max=4095". This sketch answers it by reading the AD8232's OWN
 * leads-off pins (LO+, LO-), which report whether an electrode is off skin.
 *
 * ADD THESE TWO WIRES:
 *   AD8232 LO+  ->  ESP32 GPIO32
 *   AD8232 LO-  ->  ESP32 GPIO33
 *   (keep: 3.3V -> 3V3, GND -> GND, OUTPUT -> GPIO34)
 *
 * HOW TO READ THE OUTPUT:
 *   LO+ LOW  = LA (yellow) electrode CONNECTED  (good)
 *   LO+ HIGH = LA (yellow) electrode OFF SKIN   (bad)
 *   LO- LOW  = RA (red) electrode CONNECTED     (good)
 *   LO- HIGH = RA (red) electrode OFF SKIN      (bad)
 *
 *   NOTE: if LO- always reads LOW even with pads off, your board is in AC
 *   leads-off mode — then LO+ alone reports "either pad off".
 */

const int SENSOR_PIN  = 34;
const int LO_PLUS_PIN  = 32;   // LO+  (HIGH = LA/yellow pad off)
const int LO_MINUS_PIN = 33;   // LO-  (HIGH = RA/red pad off)
const int BAUD = 115200;

void setup() {
  Serial.begin(BAUD);
  delay(800);

  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);

  // INPUT_PULLUP: if the LO wire itself is loose, it reads HIGH = "off",
  // which is the safe (assume-bad) interpretation.
  pinMode(LO_PLUS_PIN, INPUT_PULLUP);
  pinMode(LO_MINUS_PIN, INPUT_PULLUP);

  Serial.println("VocalBridge_MuscleTest_v4 (lead-off detector)");
  Serial.println("Pad ON skin  -> LO pin reads OK.");
  Serial.println("Pad OFF skin -> LO pin reads OFF.");
  Serial.println();
}

void loop() {
  const int N = 100;                 // 100 samples (~1 second)
  long sum = 0;
  int mn = 4096, mx = -1;
  int loPlusHigh = 0, loMinusHigh = 0;

  for (int i = 0; i < N; i++) {
    int v = analogRead(SENSOR_PIN);
    sum += v;
    if (v < mn) mn = v;
    if (v > mx) mx = v;
    if (digitalRead(LO_PLUS_PIN)  == HIGH) loPlusHigh++;
    if (digitalRead(LO_MINUS_PIN) == HIGH) loMinusHigh++;
    delay(10);
  }

  int avg = (int)(sum / N);
  bool laOff = (loPlusHigh  > 20);   // high most of the window = pad off
  bool raOff = (loMinusHigh > 20);

  Serial.print("avg="); Serial.print(avg);
  Serial.print("  min="); Serial.print(mn);
  Serial.print("  max="); Serial.print(mx);
  Serial.print("  | LO+ (LA/yellow) = "); Serial.print(laOff ? "OFF" : "OK");
  Serial.print("   LO- (RA/red) = "); Serial.println(raOff ? "OFF" : "OK");

  if (laOff || raOff) {
    Serial.println("  >>> LEADS-OFF DETECTED. Check in this order:");
    Serial.println("      1) LO wires real? Jumper GPIO32->GND then GPIO33->GND (one at");
    Serial.println("         a time) -> that line MUST flip to OK. If not, the LO wires");
    Serial.println("         are the problem, NOT your skin.");
    Serial.println("      2) ALL THREE pads on? GREEN/RL on elbow bone is REQUIRED:");
    Serial.println("         without it the chip reports BOTH off even if red+yellow are");
    Serial.println("         on (DC mode can't confirm contact without the 3rd lead).");
    Serial.println("      3) Clean skin, fresh gel, press firmly, snaps fully clicked.");
    if (laOff && raOff) Serial.println("      Chip says: both signal pads off-skin (or green/RL missing).");
    else if (laOff)     Serial.println("      Chip says: YELLOW (LA) pad off-skin.");
    else                Serial.println("      Chip says: RED (RA) pad off-skin.");
  } else if ((mx - mn) < 150) {
    Serial.println("  -> LEADS OK + TIGHT SIGNAL. Baseline is clean. CLENCH and watch it move.");
  } else {
    Serial.println("  -> Leads connected, but signal still swinging (saturation/motion).");
    Serial.println("     Stay perfectly still; make sure no pad or cable is moving.");
  }

  Serial.println();
}
