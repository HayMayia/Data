/*
 * VocalBridge — CLENCH DETECTOR v9 (robust auto-calibration)
 * ----------------------------------------------------------
 * v8 bug: threshold used the MAXIMUM wobble during learning, so a few
 * noisy startup samples inflated it to 828 — far above the real clench
 * (~315). FIXED here with robust statistics:
 *
 *   - baseline = MEDIAN of learning samples   (spikes can't drag it)
 *   - rest noise = MEDIAN absolute deviation  (spikes can't inflate it)
 *   - threshold = 4x noise, clamped 150..2000
 *
 * Also: each printed line now averages 0.6 s, and a CLENCH must stay
 * above threshold for 2 lines (~1.2 s). Transient noise can't do that;
 * a held clench can. So HOLD the clench 2-3 seconds.
 *
 * Board:  ESP32 Dev Module
 * Wiring: AD8232 3.3V->3V3, GND->GND, OUTPUT->GPIO34
 * Baud:   115200 (Serial Monitor)
 *
 * HOW TO USE:
 *   1) Upload. Arm FLAT on the table. Sit COMPLETELY still for 5 s.
 *   2) Note the ">>> LEARNED" threshold (should be ~150-300).
 *   3) SQUEEZE A SOFT BALL (or hard fist) and HOLD 2-3 s, then relax.
 *      ">>> CLENCH! <<<" prints once per held squeeze.
 *   4) Tuning: if it fires at rest, raise THRESHOLD; if a squeeze
 *      doesn't fire, squeeze harder / longer (see MAXdev).
 */

const int SENSOR_PIN = 34;
const int BAUD = 115200;

const int N = 60;                 // 60 samples * 10ms = 0.6 s per line
const int LEARN_MS = 5000;        // 5 s calibration window
const int MAX_LEARN = 16;         // stored learning samples
const int FIRE_STREAK = 2;        // 2 lines (~1.2 s) held -> fire
const int COOLDOWN_MS = 2500;     // ignore repeats after a detection

int learnSamples[MAX_LEARN];
int learnCount = 0;
unsigned long learnStart = 0;

float baseline = 0;
int THRESHOLD = 250;
bool learned = false;

int aboveStreak = 0;
int sessionMaxDev = 0;
unsigned long lastFireMs = 0;

void setup() {
  Serial.begin(BAUD);
  delay(800);
  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);

  Serial.println("VocalBridge_ClenchDetector_v9");
  Serial.println("SIT STILL 5 s (arm FLAT). Learning...");
  Serial.println();
  learnStart = millis();
}

int readAvg() {
  long sum = 0;
  for (int i = 0; i < N; i++) {
    sum += analogRead(SENSOR_PIN);
    delay(10);
  }
  return (int)(sum / N);
}

// ---- tiny insertion sort (arrays are small) ----
void sortArr(int *a, int n) {
  for (int i = 1; i < n; i++) {
    int v = a[i];
    int j = i - 1;
    while (j >= 0 && a[j] > v) { a[j + 1] = a[j]; j--; }
    a[j + 1] = v;
  }
}

void loop() {
  int avg = readAvg();

  // ---------------- CALIBRATION ----------------
  if (!learned) {
    if (learnCount < MAX_LEARN) learnSamples[learnCount++] = avg;

    Serial.print("learning ");
    Serial.print((millis() - learnStart) / 1000);
    Serial.print("s  avg=");
    Serial.println(avg);

    if (millis() - learnStart >= LEARN_MS && learnCount >= 8) {
      int sorted[MAX_LEARN];
      for (int i = 0; i < learnCount; i++) sorted[i] = learnSamples[i];
      sortArr(sorted, learnCount);

      int med = sorted[learnCount / 2];          // robust baseline
      baseline = med;

      int devs[MAX_LEARN];
      for (int i = 0; i < learnCount; i++) {
        int d = sorted[i] - med;
        if (d < 0) d = -d;
        devs[i] = d;
      }
      sortArr(devs, learnCount);
      int mad = devs[learnCount / 2];            // robust noise

      THRESHOLD = mad * 4;
      if (THRESHOLD < 150) THRESHOLD = 150;
      if (THRESHOLD > 2000) THRESHOLD = 2000;

      learned = true;
      Serial.println();
      Serial.print(">>> LEARNED: baseline = "); Serial.print(med);
      Serial.print(", rest noise = "); Serial.print(mad);
      Serial.print(", threshold = "); Serial.println(THRESHOLD);
      Serial.println(">>> SQUEEZE and HOLD 2-3 s. It fires on a HELD squeeze.");
      Serial.println();
    }
    return;
  }

  // ---------------- RUNNING ----------------
  int dev = avg - (int)baseline;
  int absDev = dev < 0 ? -dev : dev;

  if (absDev > sessionMaxDev) sessionMaxDev = absDev;

  if (aboveStreak == 0) {
    baseline = baseline * 0.998 + avg * 0.002;   // very slow drift
  }

  bool above = absDev > THRESHOLD;
  if (above) aboveStreak++;
  else aboveStreak = 0;

  if (aboveStreak == FIRE_STREAK && (millis() - lastFireMs > (unsigned long)COOLDOWN_MS)) {
    Serial.println(">>> CLENCH! <<<");
    lastFireMs = millis();
  }

  Serial.print("avg="); Serial.print(avg);
  Serial.print("  dev="); Serial.print(dev);
  Serial.print("  thr="); Serial.print(THRESHOLD);
  Serial.print("  streak="); Serial.print(aboveStreak);
  Serial.print("  MAXdev="); Serial.print(sessionMaxDev);
  Serial.println(above ? "  [above]" : "");
}
