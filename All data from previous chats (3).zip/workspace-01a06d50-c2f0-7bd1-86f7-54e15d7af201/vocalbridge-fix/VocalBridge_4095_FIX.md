# VocalBridge — Why the AD8232 reads "only 4095" (and how to actually fix it)

## The one fact that changes everything

A healthy AD8232 powered from 3.3 V outputs **~1.65 V at rest** (half its supply voltage).
On your ESP32, `analogReadResolution(12)` + `ADC_11db` means:

| Voltage on GPIO34 | Reading you should get |
|---|---|
| 0.0 V | ~0 |
| 1.1 V | ~1365 |
| **1.65 V (healthy AD8232 at rest)** | **~2048** |
| 3.3 V | **4095** |

So a working setup should show **~2048 at rest, moving when you clench** — never a constant 4095.

**4095 means the pin is at ~3.3 V (full scale).** The AD8232's OUTPUT never sits at 3.3 V
in normal operation. Therefore "stuck at 4095" is **not a muscle-signal problem and not an
electrode problem** — it is an **electrical connection problem**. This is the key point the
earlier chat kept missing: it kept telling you to fix electrodes, but bad electrodes give
~2048 (leads-off), not 4095.

> **Stuck at 4095 = the wire that should carry the sensor's 1.65 V signal to GPIO34 is
> either not connected, not powered, or shorted to 3.3 V.**

---

## Step 1 — Prove your ESP32 ADC works (2 minutes, no sensor)

Run `ADC_SelfTest.ino` (in this folder). Then, while it prints numbers:

1. **Nothing connected to GPIO34** → numbers jump around randomly (noise). ✅ normal
2. **Jumper GPIO34 → GND** → should read **0**
3. **Jumper GPIO34 → 3V3** → should read **4095**
4. **Touch GPIO34 with your finger** → numbers jump wildly (mains hum). ✅ normal

- If 2 and 3 both work: **your ESP32, pin, and code are 100% fine.** Move to Step 2.
- If 3V3 doesn't give ~4095 or GND doesn't give ~0: wrong pin / bad board / wrong board
  selected in Arduino IDE. Try pin 35 instead of 34 (both are input-only ADC pins).

---

## Step 2 — The fix: solder your connections

From your own chat: *"Your AD8232 has no soldered headers. Temporary poke-in wires will keep
giving 0 / 4095 / junk."* That was the right diagnosis. A poke-in wire that loses contact
leaves GPIO34 **floating**, and a floating ESP32 ADC input reads mostly **4095** — exactly
what you described ("main value 4095 at start", "stuck near 4095", ~61% of samples).

Do this:

1. **Solder a 3-pin male header** onto the AD8232's 3.3V / GND / OUTPUT holes.
   (Or, at minimum: push jumper wires in FIRMLY and tape the module + wires flat so nothing
   can wiggle while you test.)
2. Wire it exactly like this:

| AD8232 pin | ESP32 pin |
|---|---|
| 3.3V (VCC) | **3V3** |
| GND | **GND** |
| OUTPUT | **GPIO34** |
| LO+, LO-, SDN | leave unconnected |

3. **Check nothing is touching 3V3 that shouldn't be.** If the OUTPUT wire even grazes the
   3V3 rail (loose breadboard, stray strand of wire), the ADC reads 4095 forever. Pull the
   module away from the power rails, use clean separate wires, and keep 3V3 far from OUTPUT.
4. Power the AD8232 from **3.3 V only — NOT 5 V**.

---

## Step 3 — The 10-second truth test (multimeter OR finger test)

**If you have a multimeter:** measure the AD8232 OUTPUT pin vs GND (module powered, pads
stuck on your forearm):
- **~1.65 V** → sensor is fine; the problem was the wire to the ESP32.
- **0 V or 3.3 V** → module not powered, faulty, or shorted; fix power/board.

**If you don't have a multimeter:** upload `VocalBridge_MuscleTest_v2.ino`. It prints a
verdict every second:
- "✅ Healthy baseline (~2048)" → fixed!
- "⚠ RAILED HIGH (~4095)" → connection/power/short — go back to Step 2.

Also: with power ON and pads off, **the AD8232 OUTPUT is still ~1.65 V (~2048)**. So if you
read 4095 *even with pads disconnected*, the pads are 100% not the cause — it's the wiring.

---

## Step 4 — Only AFTER 4095 is gone, sort the electrodes

Once you see ~2048 at rest, now electrode placement decides how well the clench shows up.
Your cable is labeled **"R, R, L"** — those are really **RL, RA, LA** (the "A" and "L" got
cut off / misread). Map them like this:

| Your label | Real label | Colour (yours) | Where it goes (forearm test) |
|---|---|---|---|
| "R" (green) | **RL** = Right Leg | green | **Elbow bone** (bony, quiet reference — NOT on muscle) |
| "R" (red) | **RA** = Right Arm | red | Forearm **muscle**, pad 1 |
| "L" (yellow) | **LA** = Left Arm | yellow | Same forearm **muscle**, pad 2, 3–5 cm from red |

- Red + yellow = the sensing pair (both on the same muscle).
- Green = reference on the elbow bone.
- All three pads must be stuck on skin, snaps fully clicked, cable fully in the 3.5 mm jack.

Good contact test: run `VocalBridge_MuscleTest.ino` (plotter). At rest ~2048 and steady;
**clench fist → line jumps and returns** = hardware works, move on to the HELP threshold.

---

## Quick checklist (copy this)

- [ ] Ran ADC_SelfTest: GND → 0 and 3V3 → 4095 ✅
- [ ] Headers soldered (or wires taped rock-solid), nothing loose
- [ ] AD8232 3.3V → ESP32 3V3, GND → GND, OUTPUT → GPIO34
- [ ] Powered from 3.3 V (not 5 V), OUTPUT wire nowhere near 3V3 rail
- [ ] See ~2048 at rest (not 4095)
- [ ] Green/RL on elbow bone, red/RA + yellow/LA on the same forearm muscle
- [ ] Clench → reading jumps, relax → returns

---

## If it's STILL 4095 after soldering + correct wiring

- Try **GPIO35** instead of 34 (rare board faults / damaged pin).
- Try a **different jumper wire** (a wire can be broken internally).
- Try powering from a **power bank** (not the PC's USB) — some laptop USB ports give a dirty
  3.3 V that confuses clones.
- If multimeter shows OUTPUT = 3.3 V even with clean 3.3 V power and nothing shorted → the
  **AD8232 module is faulty** (common with cheap clones). Replace it (~₹150–250).

## Phase 2 — 4095 is gone, but now `min=0  max=4095`

If your average is rock-steady at **~2047** but `min=0` and `max=4095` appear every
second, the wiring is NOT the problem (a loose wire would make the average jumpy too).
This is the AD8232 **OUTPUT swinging between 0 V and 3.3 V** — the front-end saturating.
Almost always the cause is **leads-off detection firing**: an electrode pad is not truly
on the skin.

- **Proof:** read the AD8232's own `LO+` / `LO-` pins (see `VocalBridge_MuscleTest_v4.ino`).
  HIGH = that electrode is off the skin.
- **Fix:** clean the skin (alcohol, let it dry), use fresh gel pads, press firmly, snap fully.
  Green/RL → elbow bone, red+yellow → the same forearm muscle. Stay still while reading.
- **Expectation:** with the AD8232's fixed ~100× gain, a hard clench WILL rail the output —
  that's saturation, not a fault. Your "signal" is the *deviation* from the ~2047 baseline.

## Files in this folder

| File | Use |
|---|---|
| `ADC_SelfTest.ino` | Prove ESP32 ADC + pin + code work (Step 1) |
| `VocalBridge_MuscleTest_v2.ino` | Muscle test with voltage + automatic 4095 diagnosis (Step 3) |
| `VocalBridge_MuscleTest_v3.ino` | Muscle test with contact-quality % (rail-hit counter) |
| `VocalBridge_MuscleTest_v4.ino` | Muscle test + **leads-off detector** (LO+/LO-) — the definitive pad-contact test |
| `VocalBridge_4095_FIX.md` | This guide |
