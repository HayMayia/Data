/*
 * VocalBridge — MUSCLE TEST v2 (with automatic 4095 diagnosis)
 * ------------------------------------------------------------
 * Purpose: Same muscle test as before, BUT it also tells you WHAT is wrong
 *          when the reading is stuck at 4095.
 *
 * Board:  ESP32 Dev Module
 * Wiring: AD8232 3.3V -> 3V3, GND -> GND, OUTPUT -> GPIO34
 * Baud:   115200 (use the SERIAL MONITOR, not the plotter)
 *
 * WHAT THE VERDICTS MEAN:
 *   "RAILED HIGH (~4095)"   -> pin sees ~3.3V: wire loose/floating, shorted to 3V3,
 *                              or module not powered. FIX WIRING FIRST.
 *   "Healthy baseline"      -> ~2048 (1.65V): sensor is fine. Now clench and watch it move.
 *   "Stuck low (~0)"        -> wire to GND, or module not powered. Check GND + 3V3.
 *
 * After this test passes, switch back to VocalBridge_MuscleTest.ino + Serial Plotter
 * to watch rest-vs-clench as a graph.
 */

const int SENSOR_PIN = 34;
const int BAUD = 115200;

void setup() {
  Serial.begin(BAUD);
  delay(800);

  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);
  pinMode(SENSOR_PIN, INPUT);

  Serial.println("VocalBridge_MuscleTest_v2");
  Serial.println("Stick all 3 pads on. Rest first, then clench hard, then relax.");
  Serial.println("(A healthy signal sits near 2048 = 1.65 V at rest.)");
  Serial.println();
}

void loop() {
  // Sample for 1 second and compute min / max / average
  const int N = 100;
  long sum = 0;
  int mn = 4096, mx = -1;
  unsigned long t0 = millis();

  for (int i = 0; i < N; i++) {
    int v = analogRead(SENSOR_PIN);
    sum += v;
    if (v < mn) mn = v;
    if (v > mx) mx = v;
    delay(10);
  }

  int avg = (int)(sum / N);
  float mv = avg / 4095.0 * 3300.0;

  Serial.print("avg="); Serial.print(avg);
  Serial.print("  (~"); Serial.print((int)mv); Serial.print(" mV)");
  Serial.print("  min="); Serial.print(mn);
  Serial.print("  max="); Serial.print(mx);

  if (avg > 4000) {
    Serial.println();
    Serial.println("  >>> RAILED HIGH (~4095): pin sees ~3.3 V.");
    Serial.println("  >>> This is NOT an electrode problem. Check, in order:");
    Serial.println("       1) OUTPUT wire really connected to GPIO34 (solder headers!)");
    Serial.println("       2) OUTPUT wire not touching the 3V3 rail (short)");
    Serial.println("       3) AD8232 actually powered (3V3->3V3, GND->GND)");
    Serial.println("       4) Not powered from 5V");
  }
  else if (avg < 200) {
    Serial.println();
    Serial.println("  >>> STUCK LOW (~0): pin sees ~0 V.");
    Serial.println("  >>> Check OUTPUT wire is on GPIO34 (not GND), and GND is common.");
  }
  else if (avg > 1600 && avg < 2500) {
    Serial.println("  -> Healthy baseline (~2048). Now CLENCH and watch avg/max rise.");
  }
  else {
    Serial.println("  -> Reading active (neither railed nor resting). Watch the numbers.");
  }

  Serial.println();
}
